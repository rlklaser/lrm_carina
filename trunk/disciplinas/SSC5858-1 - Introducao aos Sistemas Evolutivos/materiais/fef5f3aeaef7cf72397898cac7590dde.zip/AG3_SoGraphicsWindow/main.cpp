// Programa para Testar um AG
// O AG tende a convergir para os otimos locais da funcao!
// Tentem usar o genocidio ou predacao para encontrar o otimo global!


// A T E N C A O !
        // Pra funcionar o Graphics.h
        // Tem que comecar o projeto como C++
        // Tem que incluir no Project -> Build Options -> Linker Settings:
                // bgi
                // gdi32
                // comdlg32
                // uuid
                // oleaut32
                // ole32

//Funcoes da Graphics.h:
//      void line (int x1, int y1, int x2, int y2);
//
//      void linerel (int dx, int dy);
//
//      void lineto (int x, int y);
//
//      void outtext (char *textstring);
//
//      void outtextxy (int x, int y, char *textstring);
//
//      void pieslice (int x, int y, int stangle, int endangle, int radius);
//
//      void putpixel (int x, int y, int color);
//
//      void rectangle (int left, int top, int right, int bottom);
//
//      setcolor(BLUE);             // Change drawing color to BLUE.
//      setcolor(COLOR(255,100,0)); // Change drawing color to reddish-green.
//      void setbkcolor (int color);

//Color Name	Value
    //BLACK 	0
    //BLUE	1
    //GREEN	2
    //CYAN	3
    //RED	4
    //MAGENTA	5
    //BROWN	6
    //LIGHTGRAY	7
    //DARKGRAY	8
    //LIGHTBLUE	9
    //LIGHTGREEN	10
    //LIGHTCYAN	11
    //LIGHTRED	12
    //LIGHTMAGENTA	13
    //YELLOW	14
    //WHITE	15

#define TamPop 10
#define TaxMut 1   // 10 = 10%
#define maxx 40
#define zoomx 1.0
#define zoomy 10.0

#include <graphics.h>
#include <stdio.h>  // Printf, sprintf
#include <stdlib.h> // Rand
#include <math.h>
#include <time.h>

double ind[TamPop];
double fit[TamPop];
double maxfit = 0.0;
double media = 0.0;
int    maxi  = 0;
int    w = 0;
int    i, g = 0;
int    key, show, step, passa;
char   msg[100];

void initpop()
{
    for (i=1;i<=TamPop;i++)
    {
        ind[i] = (double) (rand() %(maxx * 10)/10.0);
    }
}

void avalia()
{
    double x;
    for (i=1;i<=TamPop;i++)
    {
        x=ind[i];
        fit[i] = 2*cos(0.39*x) + 5*sin(0.5*x) + 0.5*cos(0.1*x) + 10*sin(0.7*x) + 5*sin(1*x) + 5*sin(0.35*x);
    }

  /*  //Funcao Sobe e Desce
  for (i=1;i<=TamPop;i++)
    {
        x=ind[i];
        if (x>=0.0 and x<10.0)
            fit[i] = x;
        else if (x>=10.0 and x<20.0)
            fit[i] = 20.0 - x;
        else
            fit[i] = 0.0;
    }*/
}

void elitismo() // Melhor transa com todos
{
    maxfit = fit[1];
    maxi   = 1;
    for (i=2;i<=TamPop;i++)  // Busca pelo melhor individuo
    {
        if (fit[i]>maxfit)
        {
            maxfit = fit[i];
            maxi = i;
        }
    }

    for (i=1;i<=TamPop;i++)
    {
        if (i==maxi)        // Protege o melhor individuo
            continue;

        // Crossover
        ind[i] = (ind[i] + ind[maxi])/ 2.0;

        // Mutacao                    | nr = 0-40 |    - 20    |  0,02  |  10%
        ind[i] = ind[i] + (double) (((rand() %maxx - (maxx/2.0))/100.0) * TaxMut);
    }
}

void torneio()
{
    int a, b, pai1, pai2;
    maxfit = fit[1];
    maxi   = 1;
    for (i=2;i<=TamPop;i++)    // Busca pelo melhor individuo para protege-lo
    {
        if (fit[i]>maxfit)
        {
            maxfit = fit[i];
            maxi = i;
        }
    }

    for (i=1;i<=TamPop;i++)
    {
        if (i==maxi)    // Protege o melhor individuo
            continue;

        // Sorteia dois individuos para 1ro torneio
        a = (rand() %TamPop) + 1;
        b = (rand() %TamPop) + 1;
        if (fit[a] > fit[b])
            pai1 = a;
        else
            pai1 = b;

        // Sorteia mais dois individuos para 2do torneio
        a = (rand() %TamPop) + 1;
        b = (rand() %TamPop) + 1;
        if (fit[a] > fit[b])
            pai2 = a;
        else
            pai2 = b;

        // Crossover
        ind[i] = (ind[pai1] + ind[pai2])/ 2.0;

        // Mutacao                    | nr = 0-40 |    - 20    |  0,02  |  10%
        ind[i] = ind[i] + (double) (((rand() %maxx - (maxx/2.0))/100.0) * TaxMut);
    }
}


void drawfunction()
{
    double x,y;
    int j,k;

    setcolor(BLUE);
    line(0,300,800,300);    // Eixo X
    for (j=0;j<=800;j++)
    {
        x = zoomx * (j * (double)(maxx/800.0));   // Divide maxX em 800 pontos

        y = 2*cos(0.39*x) + 5*sin(0.5*x) + 0.5*cos(0.1*x) + 10*sin(0.7*x) + 5*sin(1*x) + 5*sin(0.35*x);  // Calcula a F(x) normalmente

        k = (int) (300 - y * zoomy);   // Inverte o Eixo Y e faz k=300 quando Y=0

        putpixel(j,k,12);  // Color = Light red
    }

}

  int main()
  {
// Liga Tela Grafica
   {
    initwindow(800,600);                    //open a 800x600 graphics window
    setactivepage(1); setvisualpage(1);     // Liga a Tela 1! A graphics tem 2 Telas!!
    //settextstyle(TRIPLEX_FONT,HORIZ_DIR,0);   // Define o tipo de fonte do texto
    //setusercharsize(1,2,1,2);                 // Define a escala do texto
    setcolor(WHITE);                          // Define a cor
    setbkcolor(BLACK);    // Seleciona cor de fundo da tela: preta
    cleardevice();        // Limpa tela (deixa toda tela preta)

    outtextxy(1,1, "Type q -> quit; x -> pause; p -> step; i -> reinitialize Evolution; h -> show/hide");

    srand(time(NULL));  // generate the seed for randomness
    }

    drawfunction();


inicio:     // Reinicializa Variaveis de controle, Geracao e Populacao
    g = 0;  // Geracoes

    // Variaveis de Controle (Flags)
    {
        show = 'a';     // Mostra Geracoes e Individuos e Grafico
    step = 'x';     // Execussao Passo a Passo
    passa = 'a';    // Pula de geracao em geracao: a = Nao Pula!!
    }

    initpop();      // Inicializa Populacao

loop:               // Loop Principal
    g++;

    avalia();       // Avalia os individuos da Populacao

    // Seleciona();

    // Crossover();

    // Mutacao();

    elitismo();    // Seleciona o melhor individuo para transar com todos e Faz Crossover e Mutacao e ja' substitui na Populacao

    //torneio();    // FAz torneio de 2 entre os individuos, e Faz Crossover e Mutacao e ja' substitui na Populacao

    // Final do Algoritmo Evolutivo

    // Inicio da parte grafica

    if (show == 'a')    // Se quizer ver a evolucao dos individuos passo a passo -> Fica mais lento!
    {
        media = 0.0;    // Calcula a Media do Fitness da Populacao
        for (i=1;i<=TamPop;i++) media = media + fit[i];
        media = media / TamPop;

        // Gera string para imprimir na tela grafica!
        setcolor(WHITE);
        sprintf(msg,"Ger = %08d  Melhor = %2d  Fitness Melhor = %3.6f  Media Fitness = %f  TaxMut = %d ", g, maxi, fit[maxi], media, TaxMut);
        outtextxy(1,20,msg);

        setcolor(BLUE);    // Risca eixo X para apagar risquinhos dos individuos
        line(0,300,800,300);

        setcolor(GREEN);    // Marca a pos X de cada individuo no grafico
        for (i=1;i<=TamPop;i++)
        {
            w = (int)(ind[i] / (zoomx * (double)(maxx/800.0)));  // Conversao para a tela: Quando X = 40, w = 800
            line(w,297,w,303);      // Risca cada individuo

        }


        // Risca de Branco o melhor individuo !!
        w = (int)(ind[maxi] / (zoomx * (double)(maxx/800.0)));

        setcolor(WHITE);
        line(w,297,w,303);      // Risca

    }

letecla:
    if (kbhit())    // So' faz as comparacoes de teclas se uma tecla for realmente precionada para ganhar tempo
	{

        key = getch();
        if (key == 'p')     // Exibicao passo a passo: p = passa uma geracao pra frente
            passa = 'p';
        if (key == 'q')
            goto fim;       // q = sai fora do loop
        if (key == 'i')     // i = reinicializa o processo evolutivo e a Populacao
            {
                setcolor(BLACK);    // Mas antes apaga os risquinhos dos individuos no grafico!!
                for (i=1;i<=TamPop;i++)
                {
                    w = (int)(ind[i] / (zoomx * (double)(maxx/800.0)));
                    line(w,297,w,303);

                }
                goto inicio;        // Depois de apagar... Reinicializa!!
            }

        if (key == 'h')     // h = Esconde a saida de tela para Evoluir muito mais rapido!
            if(show == 'a')
                show = 'h';
            else
                show = 'a';

        if (key == 'x')    // x = trava a evolucao!  a = solta o processo!
            if(step == 'a')
                step = 'x';
            else
                step = 'a';

	}   // Fim do menu de Teclado do Kbhit

    // Controle Passo a passo
    {
    if (step == 'x' && passa == 'a')
        goto letecla;   // Congela a evolucao
    else if (step == 'x' && passa == 'p')   // Passo a passo
        passa = 'a';
    }

    if (show == 'a')    // Apaga todos os risquinhos dos individuos antes de voltar pro Loop!
    {                   // So' apaga se estiver mostrando, para nao perder tempo quando em background!!
        setcolor(BLACK);
        for (i=1;i<=TamPop;i++)
        {
            w = (int)(ind[i] / (zoomx * (double)(maxx/800.0)));
            line(w,297,w,303);
        }
    }

    goto loop;      // Volta pro Loop principal

fim:
    closegraph();        //close graphics window

    return 0;
  }
