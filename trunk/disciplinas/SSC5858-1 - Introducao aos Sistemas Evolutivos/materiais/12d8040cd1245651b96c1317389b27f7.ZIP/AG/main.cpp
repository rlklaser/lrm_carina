// Programa para Testar um AG
// O AG tende a convergir para os otimos locais da funcao!
// Tentem usar o genocidio ou predacao para encontrar o otimo global!


// A T E N C A O !
        // Pra funcionar o Graphics.h
        // Tem que comecar o projeto como C++
        // Tem que incluir no Link Options:
                //-lbgi
                //-lgdi32
                //-lcomdlg32
                //-luuid
                //-loleaut32
                //-lole32


// A T E N C A O !
// Tem que comentar a fun��o �int getmaxx(WINDOW *);� na linha 1251
// e a fun��o �int getmaxy(WINDOW *);� na linha 1252 da curses.h

// Pois dava conflito com uma fun��o de mesmo nome na GRAPHICS.H

// Essas funcoes sao redundantes, pois getmaxyx devolve y,x ao mesmo tempo!!



//Funcoes:
//      void line (int x1, int y1, int x2, int y2);
//
//      void linerel (int dx, int dy);
//
//      void lineto (int x, int y);
//
//      void outtext (char *textstring);
//
//      void outtextxy (int x, int y, char *textstring);
//
//      void pieslice (int x, int y, int stangle, int endangle, int radius);
//
//      void putpixel (int x, int y, int color);
//
//      void rectangle (int left, int top, int right, int bottom);
//
//      setcolor(BLUE);             // Change drawing color to BLUE.
//      setcolor(COLOR(255,100,0)); // Change drawing color to reddish-green.
//      void setbkcolor (int color);

//Color Name	Value
    //BLACK 	0
    //BLUE	1
    //GREEN	2
    //CYAN	3
    //RED	4
    //MAGENTA	5
    //BROWN	6
    //LIGHTGRAY	7
    //DARKGRAY	8
    //LIGHTBLUE	9
    //LIGHTGREEN	10
    //LIGHTCYAN	11
    //LIGHTRED	12
    //LIGHTMAGENTA	13
    //YELLOW	14
    //WHITE	15

#define TamPop 10
#define maxx 40
#define zoomx 1.0
#define zoomy 10.0

#include <graphics.h>
#include <stdio.h>  // Printf
#include <curses.h>
#include <math.h>

double ind[TamPop];
double fit[TamPop];
double maxfit = 0.0;
double media = 0.0;
int    maxi  = 0;
int w = 0, oldw = 0;
int i, g = 0;
int key, show, step;

void initpop()
{
    for (i=1;i<=TamPop;i++)
    {
        ind[i] = (double) (rand() %(maxx * 10)/10.0);
    }
}

void avalia()
{
    double x;
    for (i=1;i<=TamPop;i++)
    {
        x=ind[i];
        fit[i] = 2*cos(0.39*x) + 5*sin(0.5*x) + 0.5*cos(0.1*x) + 10*sin(0.7*x) + 5*sin(1*x) + 5*sin(0.35*x);
    }

  /*  for (i=1;i<=TamPop;i++)
    {
        x=ind[i];
        if (x>=0.0 and x<10.0)
            fit[i] = x;
        else if (x>=10.0 and x<20.0)
            fit[i] = 20.0 - x;
        else
            fit[i] = 0.0;
    }*/
}

void seleciona()
{
    maxfit = fit[1];
    maxi   = 1;
    for (i=2;i<=TamPop;i++)
    {
        if (fit[i]>maxfit)
        {
            maxfit = fit[i];
            maxi = i;
        }
    }
}

void crossover()
{
    for (i=1;i<=TamPop;i++)
    {
        if (i==maxi)
            continue;

        ind[i] = (ind[i] + ind[maxi] )/ 2.0;

        ind[i] = ind[i] + (double) ((rand() %maxx - (maxx/2.0))/100.0);
    }
}

void drawfunction()
{
    double x,y;
    int j,k;
    //const char* title="cara.bmp";
   // readimagefile(NULL, 60,60,100,100);  // Com NULL abre menuzinho!
//    setbkcolor(WHITE);
    setcolor(BLUE);
    line(0,300,800,300);
    line(((int)(maxx / (zoomx * (double)(maxx/800.0)))-1),290,((int)(maxx / (zoomx * (double)(maxx/800.0)))-1),310);
    for (j=0;j<=800;j++)
    {
        x = zoomx * (j * (double)(maxx/800.0));

        y = 2*cos(0.39*x) + 5*sin(0.5*x) + 0.5*cos(0.1*x) + 10*sin(0.7*x) + 5*sin(1*x) + 5*sin(0.35*x);

        k = (int) (300 - y * zoomy);

        putpixel(j,k,12);  // Color = magenta (5)
    }

}

  int main()
  {
// Liga Tela Grafica
    initwindow(800,600); //open a 400x300 graphics window
    outtextxy(30,20, "Tela Grafica !!");

    drawfunction();


// CURSES MODE
   	initscr();      // Start curses mode
	//noecho();   // Nao echoa as teclas digitadas no getch()
    clear();
	raw();      // Desliga um buffer que nao faz diferenca!!!
	keypad(stdscr, TRUE);   // Liga Teclado numerico e setas e F1..F12
	resize_term(10,100);    // Tamanho Maximo na tela de 1200x800 = 64,159
	curs_set(0);    // 0 : invisible  // 1 : normal  // 2 : very visible.

inicio:
    timeout(100000);    // Uso isso para dar o delay na movimentacao da bolinha
                        // Ou deixo "0" e dou o delay no final do codigo!!
    g = 0;
    initpop();
    show = 'a';
    step = 'x';
loop:
    g++;
    avalia();

    seleciona();

    crossover();

    if (show == 'a')
    {
        media = 0.0;
        for (i=1;i<=TamPop;i++) media = media + fit[i];
        media = media / TamPop;
        mvprintw(0,0, "Geracao = %8d  Melhor ind = %2d  Fitness Melhor ind = %3.6f   Media Fitness = %f", g, maxi, fit[maxi], media);
        mvprintw(2,0, "Type q -> quit; x -> step/continuous Evolution; i -> reinitialize Evolution; h -> show/hide Evolution");

        // Debuga funcao !!
        w = (int)(ind[maxi] / (zoomx * (double)(maxx/800.0)));

        mvprintw(5,0, "Ind = %f    Plotx = %d    Fitness = %f", ind[maxi], w, fit[maxi]);

        setcolor(BLACK);
        line(oldw,290,oldw,310);
        putpixel(oldw,300,BLUE);  // Color = magenta (5)
        setcolor(BLUE);
        line(w,290,w,310);
        oldw = w;

        refresh();      // Print it on to the real screen
    }

	key = getch();        // Wait for user input
	if (key != ERR)  // Se nao ler nada, retorna 'ERR'  !!!
	{
        if (key == 'q')
            goto fim;
        if (key == 'i')
            goto inicio;

        if (key == 'h')
            if(show == 'a')
                show = 'h';
            else
                show = 'a';

        if (key == 'x')
            if(step == 'a')
            {
                step = 'x';
                timeout(1000000);
            }
            else
            {
                step = 'a';
                timeout(0);
            }

	}


    goto loop;

fim:
    resetty();   // Reseta o tamanho da janela!
	endwin();       // End curses mode

    closegraph();        //close graphics window

    return 0;
  }
