/*#############################################################
  ##                                                         ##
  ##                      Statistics.h                       ##
  ##           -------------------------------------         ##
  ##             Copyright (c) 2004 Chang Wook Ahn           ##
  ##         (Original Copyright (c) 2001 Peter Bosman)      ##
  ##     (Some addition and modification have been made.)    ##
  ##      Gwangju Institute of Science & Technology (GIST)   ##
  ##                                                         ##
  ##                  Main Work: Statistic                   ##
  ##                                                         ##
  ##  Compute and save the statistics of MrBOA 1.0.          ##
  ##  Actual running time, number of fitness evaluations     ##
  ##                                                         ##
  ##   Note: This file shows CPU time and num. of evalutions.##
  ##         Since information about nondominated solutions  ##
  ##           has been saved in "Nondominated_Front" and    ##
  ##          "numNondom_Solutions", proximity and diversity ## 
  ##           metrics can be computed from that files.      ##
  ##                                                         ##
  #############################################################*/


/*------------------- Global Variables --------------------*/
double *run_evaluations, *run_multiobj_secs, *run_secs;
/*---------------------------------------------------------*/


void initMultipleRunStatistics( )
{
	if( multiple )
	{
		run_evaluations = (double *) Malloc( amountOfRuns * sizeof( double ) );
		run_multiobj_secs    = (double *) Malloc( amountOfRuns * sizeof( double ) );
		run_secs          = (double *) Malloc( amountOfRuns * sizeof( double ) );
	}
}

void save_statistics( void )
{
	FILE *fp;

	if( (fp=fopen("statistic", "a" )) == NULL )
		printf( "File (statistic) should not be opened!\n" );

	fprintf( fp, "%8d    %18.8lf    %20.8lf", evaluations, ((double) multiobjSeconds)/1000.0, ((double) seconds)/1000.0  );
	fprintf(fp, "\n");
}

void singleRunStatistics( void )
{
	save_statistics();
  
	printf("The statistics are obtained from the run.\n");
	printf("------------------------------------------------\n");
	printf("Evaluations      : %d\n", evaluations);
	printf("Multiobj. Secs.  : %lg\n", ((double) multiobjSeconds)/1000.0);
	printf("Seconds          : %lg\n\n", ((double) seconds)/1000.0);
}


void multipleRunStatistics()
{
   int    i;
   double val, ev_stdevs, ev_bests, ev_worsts,
		  multiobj_secs_stdevs, multiobj_secs_bests, multiobj_secs_worsts,
		  secs_stdevs, secs_bests, secs_worsts;

   double ev_averages, evalavg2, evalbest, evalworst,
	      multiobj_secs_averages, multiobj_secsavg2, multiobj_secsbest, multiobj_secsworst,
	      secs_averages, secsavg2, secsbest, secsworst;
  
   /* Evaluations */
   ev_averages   = 0.0;
   evalavg2      = 0.0;
   evalbest      = run_evaluations[0];
   evalworst     = run_evaluations[0];

   /* Multiobjective Module Time */
   multiobj_secs_averages = 0.0;
   multiobj_secsavg2      = 0.0;
   multiobj_secsbest      = run_multiobj_secs[0];
   multiobj_secsworst     = run_multiobj_secs[0];
  
   /* Total Time */
   secs_averages = 0.0;
   secsavg2      = 0.0;
   secsbest      = run_secs[0];
   secsworst     = run_secs[0];


  for( i = 0; i < amountOfRuns; i++ )
  {
	/* Evaluations */
    ev_averages += run_evaluations[i];
    evalavg2    += run_evaluations[i]*run_evaluations[i];
    if( run_evaluations[i] < evalbest )
      evalbest  = run_evaluations[i];
    else if( evalworst < run_evaluations[i] )
      evalworst = run_evaluations[i];

    /* Multiobjective Module Time */
	multiobj_secs_averages += run_multiobj_secs[i];
	multiobj_secsavg2      += run_multiobj_secs[i]*run_multiobj_secs[i];
	if( run_multiobj_secs[i] < multiobj_secsbest )
		multiobj_secsbest  = run_multiobj_secs[i];
	else if( multiobj_secsworst < run_multiobj_secs[i] )
		multiobj_secsworst = run_multiobj_secs[i];


	/* Total Time */
    secs_averages += run_secs[i];
    secsavg2      += run_secs[i]*run_secs[i];
    if( run_secs[i] < secsbest )
      secsbest  = run_secs[i];
    else if( secsworst < run_secs[i] )
      secsworst = run_secs[i];
  }

  /* Evaluations */
  ev_averages /= (double) amountOfRuns;
  val          = (evalavg2 / ((double) amountOfRuns)) - ev_averages*ev_averages;
  ev_stdevs    = val <= 0 ? 0 : sqrt( val );
  ev_bests     = evalbest;
  ev_worsts    = evalworst;

  /* Multiobjective Module Time */
  multiobj_secs_averages /= (double) amountOfRuns;
  val                     = (multiobj_secsavg2 / ((double) amountOfRuns)) - multiobj_secs_averages*multiobj_secs_averages;
  multiobj_secs_stdevs    = val <= 0 ? 0 : sqrt( val );
  multiobj_secs_bests     = multiobj_secsbest;
  multiobj_secs_worsts    = multiobj_secsworst;
  
  /* Total Time */
  secs_averages /= (double) amountOfRuns;
  val            = (secsavg2 / ((double) amountOfRuns)) - secs_averages*secs_averages;
  secs_stdevs    = val <= 0 ? 0 : sqrt( val );
  secs_bests     = secsbest;
  secs_worsts    = secsworst;

  printf("The statisics are obtained from iterations.\n");
  printf("----------------------------------------------------\n");
  printf("Smallest Evaluations            : %lf\n", ev_bests);
  printf("Largest Evaluations             : %lf\n", ev_worsts);
  printf("Avg. Evaluations                : %lf\n", ev_averages);
  printf("Std. Evaluations                : %lf\n", ev_stdevs);
  printf("Fastest Multiobj. Exe. Time(s)  : %lg\n", multiobj_secs_bests);
  printf("Slowest Multiobj. Exe. Time(s)  : %lg\n", multiobj_secs_worsts);
  printf("Avg. Multiobj. Exe. Time(s)     : %lg\n", multiobj_secs_averages);
  printf("Std. Multiobj. Exe. Time(s)     : %lg\n", multiobj_secs_stdevs);
  printf("Fastest Exe. Time(s)            : %lg\n", secs_bests);
  printf("Slowest Exe. Time(s)            : %lg\n", secs_worsts);
  printf("Avg. Exe. Time(s)               : %lg\n", secs_averages);
  printf("Std. Exe. Time(s)               : %lg\n", secs_stdevs);
  printf("--------------------------------------------------\n\n");

}

void setMultipleRunStatistics( int run )
{
	save_statistics();

	run_evaluations[run] = evaluations;
	run_multiobj_secs[run]  = ((double) multiobjSeconds)/1000.0;
	run_secs[run]        = ((double) seconds)/1000.0;
}
