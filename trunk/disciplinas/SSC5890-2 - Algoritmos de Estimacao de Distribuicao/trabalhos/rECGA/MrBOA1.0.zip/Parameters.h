/*#############################################################
  ##                                                         ##
  ##                        Parameters.h                     ##
  ##           -------------------------------------         ##
  ##             Copyright (c) 2004 Chang Wook Ahn           ##
  ##     Gwangju Institute of Science & Technology (GIST)    ##
  ##                                                         ##
  ##               Main Work: Parameter loading              ##
  ##                                                         ##
  ##  This module reads the "inputFile" and set parameters.  ##
  ##                                                         ##
  #############################################################*/


/************************************************************************/
/**                           Input Parameters                         **/
/************************************************************************/
short  saveModel;
int    amountOfRuns, dimensions, popsize, maxeval, kappa, numMixComponents, numObjectives;
double tau, lowerRange, upperRange, epsilon, leaderThreshold;
/************************************************************************/

int maximumAmountOfClusters=100;  // Maximum number of possible clusters for leader algorithm.
short OptimizeType_RawFit, OptimizeType_Fitness, Func_Type, multiple, useClusters;  // They are a kind of Flag.

/*########## Optimization Type ##############*/
const int MIN=100;
const int MAX=101;
/*###########################################*/

/*====== The constant integers difine indentities of test problems. =======*/
/*====== When you add test functions, please add some parameters below. ===*/
const int MDPI   = 1;
const int MDPII  = 2;
const int MNSP   = 3;
const int ZDT4   = 4;
const int ZDT6   = 5;
/*======================================================================*/



int find_function_type( char * );
void print_parameters( void );

void read_parameters( )
{
    int i, count=0, Len;
    char s[100];
    FILE *stream;
    stream = fopen("InputFile", "rt");

    if( stream == NULL ) {
        printf("Fail to Open InputFile!!\n");
        exit(1);
    }

    while( 1 )
    {
        if( fgets(s,100,stream) )  {
            
            if( !strncmp(s, "END", 3) ) break;

            if ((s[0]) && (s[0] != '\n') && (s[0] != '%')) {
                count++;
                
                if( count == 1 || count == 2 || count == 3) {
                    Len = strlen(s);
                    for ( i=0; i<Len; i++ ) {
                        if (s[i]=='\n') Len = i;
                        else s[i] = toupper(s[i]);
                    }
                    
                    switch( count ) {
                    case 1:
                        if ( !strncmp(s, "SAVE_MODEL_YES", Len ) )  saveModel = 1;
                        else saveModel = 0;
                        break;
                    case 2:
                        if ( !strncmp(s, "MINIMIZE", Len ) )  OptimizeType_RawFit = MIN;
                        else OptimizeType_RawFit = MAX;
                        break;
                    case 3:
                        if( !strncmp(s, "MINIMIZE", Len ) ) OptimizeType_Fitness = MIN;
                        else OptimizeType_Fitness = MAX;
                        break;
                    default:
                        printf("Error: There is no such case!\n");
                        exit(1);
                        break;
                    }
                }

                else if( count == 4 ) {
                    Func_Type = find_function_type( s );
                }

                else if( count == 5 ) {
                    numObjectives = atoi(s);
                }

                else if( count == 6 ) {
                    lowerRange = atof(s);
                }

                else if( count == 7 ) {
                    upperRange = atof(s);
                }

                else if( count == 8 ) {
                    dimensions = atoi(s);
                }

                else if( count == 9 ) {
                    tau = atof(s);
                }

                else if( count == 10 ) {
                    popsize = atoi(s);
                }

                else if( count == 11 ) {
                    kappa = atoi(s);
                }

                else if( count == 12 ) {
                    numMixComponents = atoi(s);
                }

                else if( count == 13 ) {
                    leaderThreshold = atof(s);
                    if( leaderThreshold < 1.0 ) useClusters = 1;
                    else    useClusters = 0;
                }

                else if( count == 14 ) {
                    epsilon = atof(s);
                }

                else if( count == 15 ) {
                    maxeval = atoi(s);
                }

                else if( count == 16 ) {
                    amountOfRuns = atoi(s);
                    if( amountOfRuns > 1 ) multiple = 1;
                    else    multiple = 0;
                }

                else {
                    printf( "Error: Abnormal Input Sequences!!\n");
                    exit(1);
                }
            }
        }
    }
}

int find_function_type( char *s )
{
    int i, Len;

    Len = strlen(s);
    for ( i=0; i<Len; i++ ) {
        if (s[i]=='\n') Len = i;
        else s[i] = toupper(s[i]);
    }
    
    if( strncmp( s, "MULTIOBJECTIVE_DECEPTIVE_I", Len ) == 0 )
        return MDPI;
    else if( strncmp( s, "MULTIOBJECTIVE_DECEPTIVE_II", Len ) == 0 )
        return MDPII;
    else if( strncmp( s, "MULTIOBJECTIVE_NONSYM_PROBLEM", Len ) == 0 )
        return MNSP;
    else if( strncmp( s, "ZDT_4", Len ) == 0 )
        return ZDT4;
    else if( strncmp( s, "ZDT_6", Len ) == 0 )
        return ZDT6;
    else {
        printf("There is no such a function!!\n");
        exit(1);
    }
}

void print_parameters() {
    printf("===============================\n");    
    if( saveModel )
        printf("Save learned model: YES\n" );
    else    printf("Save learned model: NO\n" );
    
    if( OptimizeType_RawFit == MIN )
        printf("Optimization type wrt Objective function: Minize\n");
    else    printf("Optimization type wrt Objective function: Maximize\n");
    if( OptimizeType_Fitness == MIN )
        printf("Optimization type wrt Computed fitness: Minize\n");
    else    printf("Optimization type wrt Computed fitness: Maximize\n");

    printf("Num. objectives: %d\n", numObjectives );
    printf("Lower range: %f\n", lowerRange );
    printf("Upper range: %f\n", upperRange );
    printf("Problem dimension: %d\n", dimensions );
    printf("Tau for trucation: %f\n", tau );
    printf("Population size: %d\n", popsize );
    printf("Num. parents: %d\n", kappa );
    printf("Num. mixtures: %d\n", numMixComponents );
    printf("Leader threshold: %f\n", leaderThreshold );
    printf("Termination 1: %f\n", epsilon );
    printf("Termination 2: %d\n", maxeval );
    printf("Num. runs: %d\n", amountOfRuns );
    printf("===============================\n\n");
}
