/*#############################################################
  ##                                                         ##
  ##                      RealGenotype.h                     ##
  ##           -------------------------------------         ##
  ##             Copyright (c) 2005 Chang Wook Ahn           ##
  ##      Gwangju Institute of Science & Technology (GIST)   ##
  ##                                                         ##
  ##            Main Work: Population and Individual         ##
  ##                                                         ##
  ##  Data-structures are defined here.                      ##
  ##  Population consists of real-coded individuals.         ##
  ##  Macros for directly treating individuals are defined.  ##
  ##                                                         ##
  ##    Note: This file has been produced by making some     ##
  ##          modifications into RealGenotype.h (of rBOA)    ##
  ##                                                         ##
  #############################################################*/

/*-----------------------------------------------------------------------------*/
/*  The following functions define a better condition w.r.t optimization type  */
/*  The approach is chosen for reducing computation time                       */
/*-----------------------------------------------------------------------------*/
#define SMALLER_VALUE_BETTER(X1,X2) (X1 < X2)
#define LARGER_VALUE_BETTER(X1,X2) (X1 > X2)

/*-----------------------------------------------------------------*/
/*                       Global variables                          */
/*-----------------------------------------------------------------*/
int      selsize, latestSelectionSize = 0, stringlength;
double **population, **selected;



/*-----------------------------------------------------------------*/
/*                  General Macro Functions                        */
/*-----------------------------------------------------------------*/
/*
 * Macro for setting a real.
 */
#define SETREAL(REAL,INDEX,MEMBER) (population[(MEMBER)][(INDEX)] = REAL)
#define SETREALSELECTED(REAL,INDEX,MEMBER) (selected[(MEMBER)][(INDEX)] = REAL)

/*
 * Macro for getting a real.
 */
#define GETREAL(INDEX,MEMBER) (population[(MEMBER)][(INDEX)])
#define GETREALSELECTED(INDEX,MEMBER) (selected[(MEMBER)][(INDEX)])





/************************************************************************
 *
 * Function prototypes.
 *
 ***********************************************************************/
bool BETTERFITNESS( double, double );
bool BETTER_RAWFITNESS( double, double );
void new_Population( int, int, double, double );
void make_Selected( int );
void print_Population( void );
void print_Individual( int );
void print_Selected( void );
int  equalString( int, int );

/* 
 * This function returns a better fitness value
 * on the basis of optimizatio type of problem.
 *
 */
bool BETTER_RAWFITNESS( double x1, double x2 )
{
	bool resultFlag;

	if( OptimizeType_RawFit == MIN ) {
		resultFlag = SMALLER_VALUE_BETTER( x1, x2 ) ? true : false;
	}
	else {
		resultFlag = LARGER_VALUE_BETTER( x1, x2 ) ? true : false;
	}

	return( resultFlag );
}

bool BETTERFITNESS( double x1, double x2 )
{
	bool resultFlag;

	if( OptimizeType_Fitness == MIN ) {
		resultFlag = SMALLER_VALUE_BETTER( x1, x2 ) ? true : false;
	}
	else {
		resultFlag = LARGER_VALUE_BETTER( x1, x2 ) ? true : false;
	}
	return( resultFlag );
}

/*
 * Function to create new population with random strings
 * of a specified length. The population consists of random
 * numbers in a specified range.
 */
void new_Population( int new_popsize, int new_stringlength, double low, double high )
{
  int i, j;

  if( population )
  {
    for( i = 0; i < popsize; i++ )
      if( population[i] )
        free( population[i] );

    free( population );
  }

  popsize      = new_popsize;
  stringlength = new_stringlength;
  population   = (double **) Malloc( new_popsize * sizeof( double * ) );
  for( i = 0; i < new_popsize; i++ )
  {
    population[i] = (double *) Malloc( new_stringlength * sizeof( double ) );
    for( j = 0; j < stringlength; j++ )
      SETREAL(low + (high-low)*RANDOM01(),j,i);
  }
}

/*
 * Initializing the selected array of genomes. The current entries
 * are removed and a new selected array of a specified size is made.
 * The contents of the new array is undefined.
 */
void make_Selected( int size )
{
  int i;

  if( size > latestSelectionSize )
  {
    latestSelectionSize = size;
    rawfitselected         = (double **) Malloc( size * sizeof( double *) );
	for( i = 0; i < size; i++ )
		rawfitselected[i] = (double *) Malloc( numObjectives * sizeof( double ) );


    if( selected )
    {
      for( i = 0; i < selsize; i++ )
        if( selected[i] )
          free( selected[i] );

      free( selected );
    }

    selsize  = size;
    selected = (double **) Malloc( size * sizeof( double * ) );
    for( i = 0; i < selsize; i++ )
      selected[i] = (double *) Malloc( stringlength * sizeof( double ) );
  }
}

/*
 * Function to print the real strings and their fitness
 * values in the population to standard output, followed by
 * a newline.
 */
void print_Population( void )
{
  int i, j;

  for( i = 0; i < popsize; i++ )
  {
    for( j = 0; j < stringlength; j++ )
      printf("%lf ", GETREAL(j,i));
    printf(" %lf\n", fitness[i]);
  }
}

/*
 * Function to print a single member real string
 * in the population without fitness value and newline.
 */
void print_Individual( int which )
{
  int j;

  for( j = 0; j < stringlength; j++ )
    printf("%lf ", GETREAL(j,which));
  printf(" %lf\n", fitness[which]);
}

/*
 * Function to print the real strings that were selected to
 * standard output, followed by a newline.
 */
void print_Selected( void )
{
  int i, j;

  for( i = 0; i < selsize; i++ )
  {
    for( j = 0; j < stringlength; j++ )
      printf("%lf ", GETREALSELECTED(j,i));
    printf("\n");
  }
}

/*
 * Returns 0 if two real strings are different on the
 * real level, 1 otherwise.
 */
int equalString( int which1, int which2 )
{
  int i;

  for( i = 0; i < stringlength; i++ )
    if( GETREAL( i, which1 ) != GETREAL( i, which2 ) )
      return( 0 );

  return( 1 );
}
