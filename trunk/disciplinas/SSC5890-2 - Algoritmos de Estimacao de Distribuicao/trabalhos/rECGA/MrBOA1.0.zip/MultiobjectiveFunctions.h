/*#############################################################
  ##                                                         ##
  ##                MultiobjectiveFunctions.h                ##
  ##           -------------------------------------         ##
  ##             Copyright (c) 2005 Chang Wook Ahn           ##
  ##      Gwangju Institute of Science & Technology (GIST)   ##
  ##                                                         ##
  ##           Main Work: Multiobjective functions           ##
  ##                                                         ##
  ##  Objective functions are defined in this file.          ##
  ##  To use these functions, define global parameters       ##
  ##    corresponding to the functions in "Parameters.h",    ##
  ##        and add some lines for the functions to          ##
  ##              "MultiobjectiveOperators.h".               ##
  ##                                                         ##
  #############################################################*/



//======== Real-valued Deceptive Problem ================
double RDP( int member, int numBBs )
{
	int j;
	double result, s1, y1, y2;
	result = 0;

	for( j=0; j<numBBs; j++ ) {
		y1 = GETREAL(2*j+1, member );
		y1 = y1 < 0 ? 0 : y1;
		y1 = y1 > 1 ? 1 : y1;
		SETREAL(y1, 2*j+1, member );

		y2 = GETREAL(2*(j+1), member );
		y2 = y2 < 0 ? 0 : y2;
		y2 = y2 > 1 ? 1 : y2;
		SETREAL(y2, 2*(j+1), member );
			
		s1 = SAFESQRT( (y1*y1 + y2*y2)/2.0 );

		if( s1 > 0.8 )
			result += 5.0*(s1-0.8);			
		else
			result += (0.8-s1);
	}

	return result;
}

//========== Complementary Real-valued Deceptive Problem ================
double complementRDP( int member, int numBBs )
{
	int j;
	double result, s1, y1, y2;
	result = 0;

	for( j=0; j<numBBs; j++ ) {
		y1 = GETREAL(2*j+1, member );
		y1 = y1 < 0 ? 0 : y1;
		y1 = y1 > 1 ? 1 : y1;
		SETREAL(y1, 2*j+1, member );

		y2 = GETREAL(2*(j+1), member );
		y2 = y2 < 0 ? 0 : y2;
		y2 = y2 > 1 ? 1 : y2;
		SETREAL(y2, 2*(j+1), member );
			
		s1 = SAFESQRT( (y1*y1 + y2*y2)/2.0 );

		if( s1 <= 0.8 )
			result = 1.0 - 1.25*s1;
		else
			result = 4.0*(s1-0.8);
	}

	return result;
}

//========================== Multiobjective RDP Type I =============================
double MDPI_func( int member, int objective )
{
	int numBBs = stringlength/2;
	double each_objective_value = 0.0;
	 
	if( objective == 0 )
		each_objective_value = RDP( member, numBBs );		
	else if( objective == 1 )
		each_objective_value = complementRDP( member, numBBs );
	else {
		printf("Error: there is no such a case in the multiobjective_RDP\n");
		exit(0);
	}

	return( each_objective_value );
}

//========================= Multiobjective RDP Type II =============================
double MDPII_func( int member, int objective)
{
	int numBBs;
	double objective_value, xi, tmp_value;
	tmp_value = 0.0;	numBBs = (stringlength-1)/2;

	if( objective == 0 ) {
		xi = GETREAL( 0, member );
		xi = xi < 0 ? 0 : xi;
		xi = xi > 1 ? 1 : xi;
		SETREAL( xi, 0, member );

		objective_value = xi;
	}
	else if( objective == 1 ) {
		tmp_value = RDP( member, numBBs );

		tmp_value = 1.0 + ( (double)numBBs - tmp_value );

		xi = GETREAL( 0, member );

		objective_value = (1.0 - (xi/tmp_value)*(xi/tmp_value)) * tmp_value;
	}
	else {
		printf("Error: there is no such a case in the ZDT4.\n");
		exit(0);
	}

	return( objective_value );
}


//=============== Multiobjective Nonlinear Symmetric Problem =======================
double MNSP_func( int member, int objective)
{
	int i, j, numBBs;
	double objective_value, xi, y1, y2, y3, tmp_value;
	tmp_value = 0.0;	numBBs = (stringlength-1)/3;

	if( objective == 0 ) {
		if( generation == 0 ) {
			for( i=0; i<popsize; i++ )
				SETREAL(1.0 * RANDOM01(),0,i);
		}
		xi = GETREAL( 0, member );
		xi = xi < 0 ? 0 : xi;
		xi = xi > 1 ? 1 : xi;
		SETREAL( xi, 0, member );

		objective_value = xi;
	}
	else if( objective == 1 ) {
		for( j=0; j<numBBs; j++ ) {
			y1 = GETREAL(numBBs*j+1, member );
			y1 = y1 < -5.12 ? -5.12 : y1;
			y1 = y1 > 5.12 ? 5.12 : y1;
			SETREAL(y1, numBBs*j+1, member );

			y2 = GETREAL(numBBs*j+2, member );
			y2 = y2 < -5.12 ? -5.12 : y2;
			y2 = y2 > 5.12 ? 5.12 : y2;
			SETREAL(y2, numBBs*j+2, member );

			y3 = GETREAL(numBBs*j+3, member );
			y3 = y3 < -5.12 ? -5.12 : y3;
			y3 = y3 > 5.12 ? 5.12 : y3;
			SETREAL(y3, numBBs*j+3, member );
			
			tmp_value += 100.0*(y2-y1*y1)*(y2-y1*y1) + (1.0-y1)*(1.0-y1) + 100.0*(y3-y2*y2)*(y3-y2*y2) + (1.0-y2)*(1.0-y2);
		}		
		xi = GETREAL( 0, member );

		objective_value = (1.0 - sqrt(xi/(1.0+tmp_value)) ) * (1.0+tmp_value);
	}
	else {
		printf("Error: there is no such a case in the ZDT4.\n");
		exit(0);
	}

	return( objective_value );
}

//========================= ZDT 4 ====================================
double ZDT4_first_objective( int );
double ZDT4_second_objective(int );
double ZDT4_func( int member, int objective )
{
	double each_objective_value = 0.0;

	if( objective == 0 ) {
		each_objective_value = ZDT4_first_objective( member );		
	}
	else if( objective == 1 ) {
		each_objective_value = ZDT4_second_objective( member );
	}
	else {
		printf("Error: there is no such a case in the ZDT4.\n");
		exit(0);
	}

	return( each_objective_value ); 
}

double ZDT4_first_objective( int member)
{
	int i;
	double xi, objective_value;

	if( generation == 0 ) {
		for( i=0; i<popsize; i++ )
			SETREAL(1.0 * RANDOM01(),0,i);
	}

	xi = GETREAL( 0, member );
    xi = xi < 0 ? 0 : xi;
    xi = xi > 1 ? 1 : xi;
	SETREAL( xi, 0, member );

	objective_value = xi;

	return( objective_value );
}

double ZDT4_second_objective( int member )
{
	int i;
	double xi, tmp_value, first_objective_value, objective_value;

	
	first_objective_value = GETREAL(0, member );
	
	tmp_value = 0.0;
	for( i=1; i<stringlength; i++ ) {
		xi = GETREAL(i, member );
		xi = xi < -5 ? -5 : xi;
		xi = xi > 5 ? 5 : xi;
		SETREAL(xi, i, member );
		
		tmp_value += ( xi*xi -  10.0*cos(4.0*PI*xi) );
	}
	
	tmp_value += 1.0 + 10.0*( (double) stringlength - 1.0 );
	
	objective_value = tmp_value * (1.0 - SAFESQRT( first_objective_value/tmp_value ));

	return( objective_value );
}


//=========================== ZDT 6 ====================================
double ZDT6_first_objective( int );
double ZDT6_second_objective( int, double );
double ZDT6_func( int member, int objective )
{
	double each_objective_value = 0.0;

	if( objective == 0 ) {
		each_objective_value = ZDT6_first_objective( member );
	}
	else if( objective == 1 ) {
		each_objective_value = ZDT6_second_objective( member, ZDT6_first_objective(member) );
	}
	else{
		printf("Error: there is no such a case in the ZDT6.\n");
		exit(0);
	}

	return( each_objective_value ); 
}

double ZDT6_first_objective( int member )
{
	double xi, objective_value;
	
	xi = GETREAL(0, member );
	xi = xi < 0 ? 0 : xi;
	xi = xi > 1 ? 1 : xi;
	SETREAL(xi, 0, member );

	objective_value = 1.0 - exp(-4.0*xi) * pow(sin(6.0*PI*xi),6.0);

	return( objective_value );
}

double ZDT6_second_objective( int member, double first_objective_value )
{
	int i;
	double xi, tmp_value, objective_value;
	
	tmp_value = 0.0;
	for( i=1; i<stringlength; i++ ) {
		xi = GETREAL(i, member );
		xi = xi < 0 ? 0 : xi;
		xi = xi > 1 ? 1 : xi;
		SETREAL(xi, i, member );
		
		tmp_value += xi/( (double) stringlength - 1.0 ) ;
	}
	tmp_value = 1.0 + 9.0 * pow(tmp_value, 0.25);

	objective_value = tmp_value * ( 1.0 - (first_objective_value/tmp_value)*(first_objective_value/tmp_value) );

	return( objective_value );
}



