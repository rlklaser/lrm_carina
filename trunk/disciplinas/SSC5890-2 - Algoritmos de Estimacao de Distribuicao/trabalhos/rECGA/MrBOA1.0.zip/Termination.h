/*#############################################################
  ##                                                         ##
  ##                      Termination.h                      ##
  ##           -------------------------------------         ##
  ##             Copyright (c) 2004 Chang Wook Ahn           ##
  ##         (Original Copyright (c) 2001 Peter Bosman)      ##
  ##      Gwangju Institute of Science & Technology (GIST)   ##
  ##                                                         ##
  ##           Main Work: Check Termination Conditions       ##
  ##                                                         ##
  ##   Check whether all the individuals have an identical   ##
  ##     fitness or all the individuals are equal or not.    ##
  ##                                                         ##
  ##   Note: In this MrBOA, any function has not been used.  ##
  ##         Instead, maximum number of evaluation has been  ##  
  ##           used in the runSingleRun_MrBOA() of MrBOA.cc. ##
  ##         Users can define another condition and use it.  ##
  ##                                                         ##
  #############################################################*/


int allEqualFitnessValues( double );
int allEqualFitnessValuesTauN( double );
int allEqualStringGenomes( void );


/*
 * Returns 1 when all fitness values are equal within a certain epsilon, 0 otherwise.
 */
int allEqualFitnessValues( double epsilon )
{
  int i;

  for( i = 0; i < popsize-1; i++ )
    if( fitness[i] < (fitness[i+1] - epsilon) || fitness[i] > (fitness[i+1] + epsilon) )
      return( 0 );

  return( 1 );
}

/*
 * Returns 1 when all fitness values of the first selsize == tau*n individuals
 * are equal within a certain epsilon, 0 otherwise.
 */
int allEqualFitnessValuesTauN( double epsilon )
{
  int i;

  if( generation == 0 )
    return( 0 );

  for( i = 0; i < selsize-1; i++ )
    if( fitness[i] < (fitness[i+1] - epsilon) || fitness[i] > (fitness[i+1] + epsilon) )
      return( 0 );

  return( 1 );
}

/*
 * Returns 1 if all strings are equal on a genotypic level, 0 otherwise.
 */
int allEqualStringGenomes( void )
{
  int i;

  for( i = 0; i < popsize-1; i++ )
    if( !equalString( i, i+1 ) )
      return( 0 );

  return( 1 );
}
