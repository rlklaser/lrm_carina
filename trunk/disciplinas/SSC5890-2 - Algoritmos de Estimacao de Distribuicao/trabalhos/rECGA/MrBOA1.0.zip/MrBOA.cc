/******************************************************************
**                                                               **
**         Multiobjective real-coded BOA (MrBOA) ver 1.0         **
**                Copyright (c) 2005 Chang Wook Ahn              **
**                                                               **
**        Gwangju Institute of Science & Technology (GIST)       **
**           Deparment of Information & Communications           **
**      1 Oryong-dong, Buk-gu, Gwangju 500-712, Korea(south)     **
**   =========================================================   **
**                                                               **
**            This is the main program of MrBOA 1.0              **
**                                                               **
**   This program code can be distributed for academic purposes. **
**   The program has been successfully compiled with             **
**     SunOS 5.9 (gcc) and MS Visual studio 6.0.                 **
**	 Please notify me of erronous codes if any.                  **
**   The program has been built from the code of real-coded BOA. **
**  -----------------------------------------------------------  **
**              Primary E-mail: cwan@evolution.re.kr             **
**              Homepage: http://www.evolution.re.kr             **
**                                                               **
**                   Last Update: 2005 March 01                  **
**                                                               **
*******************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <float.h>
#include <ctype.h>

/***********************************************************************
 **                          Global variables.                        **
***********************************************************************/

short  *needRawfit;
int     fitsize, evaluations;
long    generation, seconds, multiobjSeconds;
double *fitness, **raw_fitness, **rawfitselected;

/* Do not change the order. */
#include "Parameters.h"
#include "Miscellaneous.h"
#include "Matrix.h"
#include "RandomNumber.h"
#include "RealGenotype.h"
#include "RealSelection.h"
#include "Termination.h"
#include "Statistics.h"
#include "rBOABody.h"

#include "MultiobjectiveFunctions.h"
#include "MultiobjectiveOperators.h"



void IO_Setting( void ) {
	/************************* For Saving Learned Model ******************************/
	FILE *fp;    
    if( (fp=fopen("learned_model", "w" )) == NULL )
        printf( "File should not be opened!\n" );
	
	fprintf(fp,"===========================================\n");
	fprintf(fp,"####  Learned Model (i.e., Linkage)    ####\n");
	fprintf(fp,"===========================================\n");
	fclose( fp );
	/***********************************************************************************/

	/**************************** For Saving Statistics ********************************/
	if( (fp=fopen("statistic", "w" )) == NULL )
		printf( "File (statistic) should not be opened!\n" );
	
	fprintf(fp,"==============================================================\n");
	fprintf(fp,"  Evaluations    Multiobj. Running Time     Total Time \n");
	fprintf(fp,"==============================================================\n");	
	
	fclose( fp );
	/************************************************************************************/

	/************************** For saving Nondominated Solutions ***********************/
	FILE *fp1, *fp2;
    if( (fp1=fopen("Nondominated_front", "w" )) == NULL )
        printf( "File should not be opened!\n" );
    if( (fp2=fopen("numNondom_solutions", "w" )) == NULL )
        printf( "File should not be opened!\n" );
	
	fclose( fp1 ); fclose( fp2 );
  /**************************************************************************************/
}

/*
 * Initialize the system parameters 
 */
void init( void )
{
	/* Make files for saving results */
	IO_Setting();

	/* Read and print system parameters of MrBOA */
	read_parameters();
	print_parameters();


	/* Initialize the random number generator */
	initRandom();

	fitsize = 0;

	/* Initialize the parameters for statistics */
	initMultipleRunStatistics();
}


/*
 * Evaluation of all individuals that have needRawfit[] set
 * to a value != 0. If the population size has changed,
 * a setup phase allocates the right amount of memory.
 */
void setupEval( void );

/*
 * Allocates memory for evaluation of fitness values.
 */
void setupEval()
{
    short  *needdummy;
    int     i, j;
    double *fitdummy, **rawfitdummy;

    if( fitsize < popsize )
    {
        needdummy = (short *) Malloc( popsize * sizeof( short ) );
        fitdummy  = (double *) Malloc( popsize * sizeof( double ) );
		rawfitdummy = (double **) Malloc( popsize * sizeof( double *) );
		for( i = 0; i < popsize; i++ )
			rawfitdummy[i] = (double *) Malloc( numObjectives * sizeof( double ) );

        for( i = 0; i < fitsize; i++ ) {
			fitdummy[i]  = fitness[i];
			for( j = 0; j < numObjectives; j++ )
				rawfitdummy[i][j] = raw_fitness[i][j];
		}

        if( needRawfit )
            free( needRawfit );
        if( fitness )
            free( fitness );
		if( raw_fitness ) {
			for( i = 0; i < fitsize; i++ )
				free( raw_fitness[i] );
			free( raw_fitness );
		}
			
        needRawfit = needdummy;
        fitness = fitdummy;
        fitsize = popsize;
		raw_fitness = rawfitdummy;
    }
    
    if( generation == 0 )
        for( i = 0; i < popsize; i++ )
            needRawfit[i] = 1;
}


/**************************************************************************/
/****                  Start Multiobjective Framework                   ***/
/**************************************************************************/

void runSingleRun_MrBOA( void );
void run_MrBOA( void )
{
  int run;

  if( multiple )
  {
    for( run = 0; run < amountOfRuns; run++ )
    {
      printf("%d ", run); fflush(stdout);
    
      runSingleRun_MrBOA();
      
      setMultipleRunStatistics( run );

      saveNondominatedSolutions();
    }
    
    printf("\n");

    multipleRunStatistics();
  }
  else {
    runSingleRun_MrBOA();

    saveNondominatedSolutions();
  }

}

/*
 * Multiobjective Evolutionary Algorithm Framework.
 */
void multiobjective_evaluate( void );
void runSingleRun_MrBOA()
{
  int i, sz;

  timeMe( 1 );

  generation        = 0;
  evaluations       = 0;
  multiobjSeconds = 0;

  new_Population( popsize, dimensions, lowerRange, upperRange );
  
  multiobjective_evaluate();
  
  sz = (int) (tau*((double) popsize));
  
  for( i = 0; i < sz; i++ )
     needRawfit[i] = 0;
  for( i = sz; i < popsize; i++ )
     needRawfit[i] = 1;

  while( evaluations < maxeval )
  {
    timeMe( 2 );

    realtruncationselection( sz );

    rBOA( useClusters, leaderThreshold, maximumAmountOfClusters );

    multiobjSeconds += timeMe( 2 );

	generation++;
	
	multiobjective_evaluate();
  }
  
  seconds           = timeMe( 1 );
  multiobjSeconds = seconds - multiobjSeconds;

  if( !multiple )
     singleRunStatistics();
}
void multiobjective_evaluate( void )
{
  setupEval();
  multiobjective_module();
}



/************************************************************************/
/****                    Main of MrBOA Version 1.0                    ***/
/************************************************************************/
int main( int argc, char *argv[] )
{
    init();
		
	run_MrBOA();

	return true;
}
