/*#############################################################
  ##                                                         ##
  ##                 MultiobjectiveOperators.h               ##
  ##           -------------------------------------         ##
  ##             Copyright (c) 2005 Chang Wook Ahn           ##
  ##     Gwangju Institute of Science & Technology (GIST)    ##
  ##                                                         ##
  ##                Main Work:  MrBOA procedures             ##
  ##                                                         ##
  ##  MrBOA combines Pareto ranking scheme (of NSGA-II) with ##
  ##    proposed adaptive sharing and dynamic crowding.      ##
  ##  The effect of the Pareto rank is to push all the indi- ##
  ##    viduals toward nondominated solutions. It can weaken ##
  ##    population diversity, but the problem is overcome by ##
  ##    by incorporating crowding and sharing methods.       ##
  ##  With this in view, fitness is assigned to nondominated ##
  ##   solutions based on Pareto ranks and crowding distance ##
  ##   and to others by their ranks and sharing intensities. ##
  ##                                                         ##
  #############################################################*/


/********************************************************************/
/**                  Global variables                              **/ 
/********************************************************************/

/* Variables used by the operators in this library */

double *crowding_distance;
int *dominating_count, *dominated_count, *tmp_dominated_count, *individual_rank, *num_ind_each_front, **pareto_front, **Sp;


void multiobjective_module( int );

void raw_fitness_eval( void );
void nondomination_sort( void );
void crowding_first_rank( void );
void multiobjective_fitness_eval( void );
void memory_deallocation( void );

void multiobjective_module( void )
{
    raw_fitness_eval();
	
    nondomination_sort();

    crowding_first_rank();

    multiobjective_fitness_eval();

    memory_deallocation();
}

void raw_fitness_eval( void )
{   
    int i, j;
    
	//======================== Raw Fitness Assignment =====================
    for( i=0; i<popsize; i++ ) {

		if( needRawfit[i] ) {

			for( j=0; j<numObjectives; j++ ) {
			
				switch(Func_Type)
				{
					case MDPI:
						raw_fitness[i][j] = MDPI_func(i,j);
						break;
					case MDPII:
						raw_fitness[i][j] = MDPII_func(i,j);
						break;
					case MNSP:
						raw_fitness[i][j] = MNSP_func(i,j);
						break;
					case ZDT4:
						raw_fitness[i][j] = ZDT4_func(i,j);
						break;
					case ZDT6:
						raw_fitness[i][j] = ZDT6_func(i,j);
						break;
					default:
						printf("There is no such problem. Please add new problems.\n");
						exit(1);
						break;
				}
			}

			evaluations++;
		}
		else {
			for( j=0; j<numObjectives; j++ )
				raw_fitness[i][j] = rawfitselected[i][j];
		}

    }
	//======================================================================
}

bool check_dominating(int, int);
bool check_dominated(int, int);
void nondomination_sort( void )
{
    int i, j, k;
    //======================= Memory Allocation ===========================    
    Sp = (int **) Malloc( popsize * sizeof( int * ) );
    pareto_front = (int **) Malloc( popsize * sizeof( int * ) );

    for( i=0; i<popsize; i++ ) {
        Sp[i] = (int *) Malloc( popsize * sizeof( int ) );
        pareto_front[i] = (int *) Malloc( popsize * sizeof( int ) );
    }       
    num_ind_each_front = (int *) Malloc( popsize * sizeof( int ) );
    individual_rank = (int *) Malloc( popsize * sizeof( int ) );
    dominating_count = (int *) Malloc( popsize * sizeof( int ) );
    dominated_count = (int *) Malloc( popsize * sizeof( int ) );
    tmp_dominated_count = (int *) Malloc( popsize * sizeof( int ) );    
    //=====================================================================

    //======================== Initialization =============================
    for( i=0; i<popsize; i++ ) {
        for( j=0; j<popsize; j++ ) {
            Sp[i][j] = 0;
            pareto_front[i][j] = 0;
        }
        num_ind_each_front[i] = 0;
        individual_rank[i] = -1;
        dominating_count[i] = 0;
        dominated_count[i] = 0;
        tmp_dominated_count[i] = dominated_count[i];
    }
    //======================================================================

    //=================== Compute dominating, dominated counts =============
    for( i=0; i<popsize; i++ ) {
        for( j=0; j<popsize; j++ ) {
            if( (i!=j) && check_dominating(i,j) ) {      // if individual i dominates individual j.
                Sp[i][dominating_count[i]] = j;
                dominating_count[i]++;
            }
            else if( (i!=j) && check_dominated(i,j) ) {
                dominated_count[i]++;
                tmp_dominated_count[i] = dominated_count[i];
            }
        }
				
        if( dominated_count[i] == 0 ) {                  // if dominated_count is zero
            individual_rank[i] = 0;                      // Individual i is the first rank.
            pareto_front[0][num_ind_each_front[0]] = i;	 // Input the corresponding individual to each pareto front.
            num_ind_each_front[0]++;			
        }
    }
    //==========================================================================

    //========================== Find each front =================================
    int tmp_p, tmp_q;
    k=0;    // Initialize the front counter

    while( num_ind_each_front[k] )                        // while nonempty for a specific pareto.
    {
        for( i=0; i<num_ind_each_front[k]; i++ ) {
            tmp_p = pareto_front[k][i];

            for( j=0; j<dominating_count[tmp_p]; j++ ) {
                tmp_q = Sp[tmp_p][j];
                tmp_dominated_count[tmp_q]--;

                if( tmp_dominated_count[tmp_q] == 0 ) {   // if zero dominated_count
                    individual_rank[tmp_q] = k+1;
                    pareto_front[k+1][num_ind_each_front[k+1]] = tmp_q;
                    num_ind_each_front[k+1]++;
                }
            }
        }
        k++;
    }
    //=================================================================================
		
}

bool check_dominating( int ind_a, int ind_b )            // Check whether ind_a dominates ind_b.
{
    int i;
	
    for( i=0; i<numObjectives; i++ ) {
		
		if( BETTER_RAWFITNESS( raw_fitness[ind_b][i], raw_fitness[ind_a][i] ) ) {
            return false;
        }
    }	
	
    return true;                                       // if ind_a dominates ind_b, return true.
}

bool check_dominated( int ind_a, int ind_b )           // Check whether ind_a is dominated by ind_b.
{
    int i;
	
    for( i=0; i<numObjectives; i++ ) {

        if( BETTER_RAWFITNESS( raw_fitness[ind_a][i], raw_fitness[ind_b][i] ) ) {
            return false;           
        }
    }
	
    return true;
}



int *realsortFront( void );
void crowding_first_rank( void )
{
    int *front_sorted;
	int i, j, before_indi, after_indi, current_indi, first_indi, last_indi;
    double tmp_crowding_dist1, tmp_crowding_dist2;
    
	crowding_distance = (double *) Malloc( popsize * sizeof( double ) );
    
	for( i=0; i<popsize; i++ )
		crowding_distance[i] = -1;
    
	int archive_size = (int) ( tau * (double) popsize );

	if( num_ind_each_front[0] > archive_size )           // In the case of needing crowding.
	{
		front_sorted = realsortFront();

		first_indi = pareto_front[0][ front_sorted[0] ];
		last_indi = pareto_front[0][ front_sorted[num_ind_each_front[0]-1] ];

		//========================== Computing crowding distances =======================================
		for( i=1; i<num_ind_each_front[0]-1; i++ )       // for the first front except for the solutions in edge.
		{			
			before_indi = pareto_front[0][ front_sorted[i-1] ];
			current_indi = pareto_front[0][ front_sorted[i] ];
			after_indi = pareto_front[0][ front_sorted[i+1] ];

			tmp_crowding_dist1 = tmp_crowding_dist2 = 0.0;

			for( j=0; j<numObjectives; j++ )
			{
			    tmp_crowding_dist1 += fabs( raw_fitness[after_indi][j] - raw_fitness[before_indi][j] ) / fabs(raw_fitness[ first_indi ][j] - raw_fitness[ last_indi ][j]); // In order for scaling.
				tmp_crowding_dist2 += fabs( raw_fitness[after_indi][j] - raw_fitness[current_indi][j] ) / fabs(raw_fitness[ first_indi ][j] - raw_fitness[ last_indi ][j]);
			}
			crowding_distance[current_indi] = tmp_crowding_dist1 * tmp_crowding_dist2;
		}
		//=================================================================================================

	    //=============== For the crowding of the first and the last solutions in the first front ==========
		before_indi = pareto_front[0][ front_sorted[0] ];
		after_indi = pareto_front[0][ front_sorted[ num_ind_each_front[0]-1 ] ];
	
		tmp_crowding_dist1 = 0;

		for( j=0; j<numObjectives; j++ ) {
			tmp_crowding_dist1 += fabs( raw_fitness[after_indi][j] - raw_fitness[before_indi][j] );
		}

	    current_indi = pareto_front[0][ front_sorted[0] ];
		crowding_distance[current_indi] = tmp_crowding_dist1 * tmp_crowding_dist1;
    
		tmp_crowding_dist1 = crowding_distance[current_indi];
		current_indi =  pareto_front[0][ front_sorted[ num_ind_each_front[0]-1 ] ];
		crowding_distance[current_indi] = tmp_crowding_dist1;   
		//====================================================================================================
	
		free( front_sorted );
	}

	else                                           // In the case of not needing crowding.
	{
		for( i=0; i<num_ind_each_front[0]; i++ ) {
			current_indi = pareto_front[0][i];
			crowding_distance[current_indi] = 0;   // Setting minimum value.
		}
	}
}


/**
 * Sorts the population with respect to the fitness function 
 * (which fitness value is better) using merge sort.
 */

void realmergesortFront( int *, int *, int, int );
int *realsortFront( void )
{
	int i, *front_sorted, *front_tosort;
	int first_front_size;

	first_front_size = num_ind_each_front[0];
  
    front_sorted = (int *) Malloc( first_front_size * sizeof( int ) );
    front_tosort = (int *) Malloc( first_front_size * sizeof( int ) );
    
	for( i = 0; i < first_front_size; i++ )
        front_tosort[i] = i;

  realmergesortFront( front_sorted, front_tosort, 0, first_front_size-1 );

  free( front_tosort );

  return( front_sorted );
}

/**
 * Implementation of merge sort for first front sorting.
 */
void realmergeFront( int *, int *, int, int, int );
void realmergesortFront( int *front_sorted, int *front_tosort, int p, int q )
{
  int r;

  if( p < q )
  {
    r = (p + q) / 2;
    realmergesortFront( front_sorted, front_tosort, p, r );
    realmergesortFront( front_sorted, front_tosort, r+1, q );
    realmergeFront( front_sorted, front_tosort, p, r+1, q );
  }
}

/**
 * Subroutine of merge sort, merging the results for population sorting.
 */
void realmergeFront( int *front_sorted, int *front_tosort, int p, int r, int q )
{
  int i, j, k, first;

  i = p;
  j = r;
  for( k = p; k <= q; k++ )
  {
    first = 0;
    if( j <= q )
    {
      if( i < r )
      {
		if( BETTER_RAWFITNESS( raw_fitness[ pareto_front[0][front_tosort[i]] ][0], raw_fitness[ pareto_front[0][front_tosort[j]] ][0] ) )  // It's enough to consider one objective.
          first = 1;
      }
    }
    else
      first = 1;

    if( first )
    {
      front_sorted[k] = front_tosort[i];
      i++;
    }
    else
    {
      front_sorted[k] = front_tosort[j];
      j++;
    }
  }

  for( k = p; k <= q; k++ )
    front_tosort[k] = front_sorted[k];
}


void multiobjective_fitness_eval( void )
{
    int i; double gamma;
    for( i=0; i<popsize; i++ )
    {
        if( individual_rank[i] == 0 ) {       // if the individual rank is the first front
			fitness[i] = (double) (individual_rank[i]+1) * ( 1.0 + (1.0/(1.0+crowding_distance[i])) );
		}
        else {                                // if the individual is not the first front.			
			gamma = 20.0;

			fitness[i] = (double) (individual_rank[i]+1) + gamma * (1.0 - 1.0/(1.0+(double)dominated_count[i])); 
		}
    }	

}

void memory_deallocation( void )
{
    int i;

    for( i=0; i<popsize; i++ ) {
        free( Sp[i] );
        free( pareto_front[i] );
    }
    free( Sp );
    free( pareto_front );

    free( num_ind_each_front );
    free( individual_rank );
    free( dominating_count );
    free( dominated_count );
    free( tmp_dominated_count );

    free( crowding_distance );    
}


void saveNondominatedSolutions()
{
	FILE *fp1, *fp2;
    if( (fp1=fopen("Nondominated_front", "a" )) == NULL )
        printf( "File should not be opened!\n" );
    if( (fp2=fopen("numNondom_solutions", "a" )) == NULL )
        printf( "File should not be opened!\n" );

	int i, j, dominatedCount, numIndiNondom, *first_front;
	numIndiNondom = 0;
	
	first_front = (int *) Malloc( popsize*sizeof( int ) );

	raw_fitness_eval( );

	for( i=0; i<selsize; i++ ) {

		dominatedCount = 0;		

		for( j=0; j<selsize; j++ ) {
			if( (j!=i) && check_dominated(i,j) ) {      // Ind i is dominated by Ind j.
				dominatedCount++;

			}
		}		
				
		if( dominatedCount == 0 ) {		
			first_front[numIndiNondom] = i;
			numIndiNondom++;
		}
	}
	for( i=0; i<numIndiNondom; i++ ) {
		for( j=0; j<numObjectives; j++ ) {
			fprintf( fp1, "%f ", raw_fitness[first_front[i]][j] );
		}
		fprintf( fp1, "\n" );
	}
	
	if( !numIndiNondom ) {
		printf("Zero solutions~ \n");
		exit(1);
	}
	fprintf( fp2, "%d\n", numIndiNondom );
	
	free( first_front );
	
	fclose( fp1 ); fclose( fp2 );
}

