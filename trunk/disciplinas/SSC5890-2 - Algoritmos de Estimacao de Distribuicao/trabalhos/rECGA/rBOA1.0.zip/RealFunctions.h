/*#############################################################
  ##                                                         ##
  ##                     RealFunctions.h                     ##
  ##           -------------------------------------         ##
  ##             Copyright (c) 2004 Chang Wook Ahn           ##
  ##      Gwangju Institute of Science & Technology (GIST)   ##
  ##                                                         ##
  ##             Main Work: Objective functions              ##
  ##                                                         ##
  ##  Objective functions are defined in this file.          ##
  ##  To use these functions, define global parameters       ##
  ##    corresponding to the functions in "Parameters.h",    ##
  ##    and add lines for the functions to "rBOA.cc".        ##
  ##                                                         ##
  #############################################################*/



/********* GLOBAL VARIABLES ************/ 
int BBSize; //For Decomposable Functions.


/*
 *  Real-Valued Deceptive Problem
 *  Domain    : [0,1]
 *  Goal      : Maximize
 */
double cTrapFunction( int, int, int, double );
double cDeceptiveProblem( int );

double cTrapFunction( int member, int startBit, double change_position ) {
    
    double FuncValue = 0.0, s1 = 0.0;
	double tmp_var1, tmp_var2;
    bool range_out = false, optimum_miss = false;
	
	tmp_var1 = GETREAL(startBit, member);
	tmp_var2 = GETREAL(startBit+1, member);

	if( tmp_var1 < 0.0 || tmp_var1 > 1.0 || tmp_var2 < 0.0 || tmp_var2 > 1.0 )
		range_out = true;
	if( tmp_var1 < change_position || tmp_var2 < change_position )
		optimum_miss = true;

	s1 = tmp_var1*tmp_var1 + tmp_var2*tmp_var2;

    s1 = SAFESQRT( s1/ double(BBSize) );

    if( range_out == false && optimum_miss == false )
        FuncValue = 1.0;
    else if( range_out == false && optimum_miss == true )
        FuncValue = 0.8 - s1;
    else
        FuncValue = 0.0;
    
    return( FuncValue);
}

double cDeceptiveProblem( int member ) {
    BBSize = 2;
    double change_position = 0.8;
    int startBit = 0;

    int NumOfBBs = stringlength/BBSize;
    double Optimality = 0.0;

    for( int i = 0; i < NumOfBBs; i++ ) {
        startBit = BBSize * i;
        Optimality += cTrapFunction( member, startBit, change_position );
    }

    Optimality /= (double) NumOfBBs;

    return( Optimality );
}

/*=== This function computes proportional correct BBs in RDP ===*/
double proportion_correctBBs( int *best_pos ) {
    int startBit = 0;
    int NumBBs = stringlength/BBSize;
    int NumCorrectBBs = 0;
    double PropBBs = 0.0;
    bool correctBBFlag;

    for( int i=0; i<NumBBs; i++ ) {
        startBit = BBSize*i;

        correctBBFlag = true;

        for( int j=0; j<BBSize; j++ ) {
            if( GETREAL( startBit+j, *best_pos ) < 0.8 )
                correctBBFlag = false;
        }
        if( correctBBFlag == true )
            NumCorrectBBs ++;
    }

    PropBBs = double(NumCorrectBBs)/double(NumBBs);
	return PropBBs;
}


/*
 *  Real-valued Nonlinear-symmetric Problem
 *  Domain		: [-5.12,5.12]
 *  Goal		: Minimize
 */
double Rosenbrock( int member, int startBit, int BBSize )
{
  int    i;
  double xi, xi1, sum;

  sum  = 0;
  for( i = 0; i < BBSize-1; i++ ) {
    xi   = GETREAL(startBit+i, member);
    xi   = xi < -5.12 ? -5.12 : xi;
    xi   = xi > 5.12 ? 5.12 : xi;
    SETREAL( xi, startBit+i, member );

    xi1  = GETREAL( startBit+i+1, member);
    
    xi1  = xi1 < -5.12 ? -5.12 : xi1;
    xi1  = xi1 > 5.12 ? 5.12 : xi1;
    SETREAL( xi1, startBit+i+1, member );

    sum += 100.0*(xi1 - xi*xi)*(xi1 - xi*xi) + (1.0 - xi)*(1.0 - xi) ;  
  }
  
  return( sum );

}

double cCONCRosenbrock( int member ) {
    BBSize = 2;
    int startBit = 0;

    int NumOfBBs = stringlength/BBSize;
    double Fitness = 0.0;
    
    for( int i = 0; i < NumOfBBs; i++ ) {
        startBit = BBSize * i;
        Fitness += Rosenbrock( member, startBit, BBSize );
    }

    Fitness /= (double) NumOfBBs;

    return( Fitness );  
}
/*#####################################################################################*/




/******************************************************************************/
/************************ Nondecomposable Problems ****************************/
/******************************************************************************/

double michalewiczFunction( int );
double rosenbrockFunction( int );

/*
 * The Michalewicz' function.
 * Domain    : [0,PI]
 * Goal      : Minimize
 */
double michalewiczFunction( int member)
{
  int    i;
  double xi, yi, sum;

  sum = 0;
  for( i = 0; i < stringlength; i++ )
  {
    xi    = GETREAL(i,member);
    xi    = xi < 0 ? 0 : xi;
    xi    = xi > PI ? PI : xi;

    yi    = (((double) (i+1))*xi*xi)/PI;
    yi    = -sin(xi)*pow(sin( yi ), 20.0);
    sum  += yi;
  }

  return( sum );
}

/*
 * The Rosenbrock's function.
 * Domain    : [-5.12,5.12]
 * Goal      : Minimize
 */
double rosenbrockFunction( int which )
{
  int    i;
  double xi, xi1, sum;

  sum  = 0;
  for( i = 0; i < stringlength-1; i++ )
  {
    xi   = GETREAL(i,which);
    xi   = xi < -5.12 ? -5.12 : xi;
    xi   = xi > 5.12 ? 5.12 : xi;
    SETREAL(xi,i,which);

    xi1  = GETREAL(i+1,which);
    xi1  = xi1 < -5.12 ? -5.12 : xi1;
    xi1  = xi1 > 5.12 ? 5.12 : xi1;
    SETREAL(xi1,i+1,which);

    sum += 100*(xi1-xi*xi)*(xi1-xi*xi) + (1.0-xi)*(1.0-xi);
  }

  return( sum );
}
