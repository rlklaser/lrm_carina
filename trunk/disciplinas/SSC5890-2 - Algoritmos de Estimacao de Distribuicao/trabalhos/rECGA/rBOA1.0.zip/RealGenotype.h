/*#############################################################
  ##                                                         ##
  ##                      RealGenotype.h                     ##
  ##           -------------------------------------         ##
  ##             Copyright (c) 2004 Chang Wook Ahn           ##
  ##         (Original Copyright (c) 2001 Peter Bosman)      ##
  ##            (Some modification has been made.)           ##
  ##      Gwangju Institute of Science & Technology (GIST)   ##
  ##                                                         ##
  ##            Main Work: Population and Individual         ##
  ##                                                         ##
  ##  Data-structures are defined here.                      ##
  ##  Population consists of real-coded individuals.         ##
  ##  Macros for directly treating individuals are defined.  ##
  ##                                                         ##
  #############################################################*/


/*-----------------------------------------------------------------*/
/*                       Global variables                          */
/*-----------------------------------------------------------------*/
int      selsize, latestSelectionSize = 0, stringlength;
double **population, **selected;



/*-----------------------------------------------------------------*/
/*                  General Macro Functions                        */
/*-----------------------------------------------------------------*/
/*
 * Macro for setting a real.
 */
#define SETREAL(REAL,INDEX,MEMBER) (population[(MEMBER)][(INDEX)] = REAL)
#define SETREALSELECTED(REAL,INDEX,MEMBER) (selected[(MEMBER)][(INDEX)] = REAL)

/*
 * Macro for getting a real.
 */
#define GETREAL(INDEX,MEMBER) (population[(MEMBER)][(INDEX)])
#define GETREALSELECTED(INDEX,MEMBER) (selected[(MEMBER)][(INDEX)])





/************************************************************************
 *
 * Function prototypes.
 *
 ***********************************************************************/
bool BETTERFITNESS( double, double );
void new_Population( int, int, double, double );
void make_Selected( int );
void shuffle_Population();
void print_Population( void );
void print_Individual( int );
void print_Selected( void );
int  equalString( int, int );

/* 
 * This function returns a better fitness value
 * on the basis of optimizatio type of problem.
 *
 */
bool BETTERFITNESS( double x1, double x2 )
{
	bool resultFlag;

	switch(Optimize_Type)  // Note: "Optimize_Type" is a global variable
	{
		case MIN:
			if( x1 < x2 ) 
				resultFlag = true;
			else	resultFlag = false;
			break;
	
		case MAX:
			if( x1 > x2 )
				resultFlag = true;
			else	resultFlag = false;
			break;
		
		default:
			printf("Error: It's invalid type of optimization!\n");
			exit(1);
			break;
	}

	return( resultFlag );
}
 

/*
 * Function to create new population with random strings
 * of a specified length. The population consists of random
 * numbers in a specified range.
 */
void new_Population( int new_popsize, int new_stringlength, double low, double high )
{
  int i, j;

  if( population )
  {
    for( i = 0; i < popsize; i++ )
      if( population[i] )
        free( population[i] );

    free( population );
  }

  popsize      = new_popsize;
  stringlength = new_stringlength;
  population   = (double **) Malloc( new_popsize * sizeof( double * ) );
  for( i = 0; i < new_popsize; i++ )
  {
    population[i] = (double *) Malloc( new_stringlength * sizeof( double ) );
    for( j = 0; j < stringlength; j++ )
      SETREAL(low + (high-low)*RANDOM01(),j,i);
  }
}

/*
 * Initializing the selected array of genomes. The current entries
 * are removed and a new selected array of a specified size is made.
 * The contents of the new array is undefined.
 */
void make_Selected( int size )
{
  int i;

  if( size > latestSelectionSize )
  {
    latestSelectionSize = size;
    fitselected         = (double *) Malloc( size * sizeof( double ) );

    if( selected )
    {
      for( i = 0; i < selsize; i++ )
        if( selected[i] )
          free( selected[i] );

      free( selected );
    }

    selsize  = size;
    selected = (double **) Malloc( size * sizeof( double * ) );
    for( i = 0; i < selsize; i++ )
      selected[i] = (double *) Malloc( stringlength * sizeof( double ) );
  }
}


/*
 * Function to shuffle the population. Convenient for
 * for instance tournament selection to prevent mating
 * the same solutions in different selection rounds.
 */
void shuffle_Population( void )
{
  short   swapneed;
  int     i, pos1, pos2;
  double  swapfit, *swap;

  for( i = 0; i < popsize; i++ )
  {
    pos1 = (int) RANDOMNUMBER( popsize );
    pos2 = (int) RANDOMNUMBER( popsize );

    swap             = population[pos1];
    population[pos1] = population[pos2];
    population[pos2] = swap;

    swapneed         = needfit[pos1];
    needfit[pos1]    = needfit[pos2];
    needfit[pos2]    = swapneed;

    swapfit          = fitness[pos1];
    fitness[pos1]    = fitness[pos2];
    fitness[pos2]    = swapfit;
  }
}

/*
 * Function to print the real strings and their fitness
 * values in the population to standard output, followed by
 * a newline.
 */
void print_Population( void )
{
  int i, j;

  for( i = 0; i < popsize; i++ )
  {
    for( j = 0; j < stringlength; j++ )
      printf("%lf ", GETREAL(j,i));
    printf(" %lf\n", fitness[i]);
  }
}

/*
 * Function to print a single member real string
 * in the population without fitness value and newline.
 */
void print_Individual( int which )
{
  int j;

  for( j = 0; j < stringlength; j++ )
    printf("%lf ", GETREAL(j,which));
  printf(" %lf\n", fitness[which]);
}

/*
 * Function to print the real strings that were selected to
 * standard output, followed by a newline.
 */
void print_Selected( void )
{
  int i, j;

  for( i = 0; i < selsize; i++ )
  {
    for( j = 0; j < stringlength; j++ )
      printf("%lf ", GETREALSELECTED(j,i));
    printf("\n");
  }
}

/*
 * Returns 0 if two real strings are different on the
 * real level, 1 otherwise.
 */
int equalString( int which1, int which2 )
{
  int i;

  for( i = 0; i < stringlength; i++ )
    if( GETREAL( i, which1 ) != GETREAL( i, which2 ) )
      return( 0 );

  return( 1 );
}
