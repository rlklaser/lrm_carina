/*#############################################################
  ##                                                         ##
  ##                        Parameters.h                     ##
  ##           -------------------------------------         ##
  ##             Copyright (c) 2004 Chang Wook Ahn           ##
  ##     Gwangju Institute of Science & Technology (GIST)    ##
  ##                                                         ##
  ##               Main Work: Parameter loading              ##
  ##                                                         ##
  ##  This module reads the "inputFile" and set parameters.  ##
  ##                                                         ##
  #############################################################*/


/************************************************************************/
/**                           Input Parameters                         **/
/************************************************************************/
short  saveModel;
int    amountOfRuns, dimensions, popsize, maxeval, kappa, numMixComponents;
double tau, lowerRange, upperRange, epsilon, leaderThreshold;
/************************************************************************/

int maximumAmountOfClusters=100; // Maximum number of possible clusters for leader algorithm.
short Optimize_Type, Func_Type, multiple, useClusters; // They are a kind of Flag.

/*########## Optimization Type ##############*/
const int MIN=100;
const int MAX=101;
/*###########################################*/

/*====== The constant integers difine indentities of test problems. =======*/
/*====== When you add test functions, please add some parameters below. ===*/
const int RDP = 1;
const int RNSP = 2;
const int MICHALE = 3;
const int ROSEN = 4;
/*======================================================================*/



int find_function_type( char * );
void print_parameters( void );

void read_parameters( )
{
    int i, count=0, Len;
    char s[100];
    FILE *stream;
    stream = fopen("InputFile", "rt");

    if( stream == NULL ) {
        printf("Fail to Open InputFile!!\n");
        exit(1);
    }

    while( 1 )
    {
        if( fgets(s,100,stream) )  {
            
            if( !strncmp(s, "END", 3) ) break;

            if ((s[0]) && (s[0] != '\n') && (s[0] != '%')) {
                count++;
                
                if( count == 1 || count == 2 ) {
                    Len = strlen(s);
                    for ( i=0; i<Len; i++ ) {
                        if (s[i]=='\n') Len = i;
                        else s[i] = toupper(s[i]);
                    }
                    
                    switch( count ) {
                    case 1:
                        if ( !strncmp(s, "SAVE_MODEL_YES", Len ) )  saveModel = 1;
                        else saveModel = 0;
                        break;
                    case 2:
                        if ( !strncmp(s, "MINIMIZE", Len ) )  Optimize_Type = MIN;
                        else Optimize_Type = MAX;
                        break;
                    default:
                        printf("Error: There is no such case!\n");
                        exit(1);
                        break;
                    }
                }

                else if( count == 3 ) {
                    Func_Type = find_function_type( s );
                }

                else if( count == 4 ) {
                    lowerRange = atof(s);
                }

                else if( count == 5 ) {
                    upperRange = atof(s);
                }

                else if( count == 6 ) {
                    dimensions = atoi(s);
                }

                else if( count == 7 ) {
                    tau = atof(s);
                }

                else if( count == 8 ) {
                    popsize = atoi(s);
                }

                else if( count == 9 ) {
                    kappa = atoi(s);
                }

                else if( count == 10 ) {
                    numMixComponents = atoi(s);
                }

                else if( count == 11 ) {
                    leaderThreshold = atof(s);
                    if( leaderThreshold < 1.0 ) useClusters = 1;
                    else    useClusters = 0;
                }

                else if( count == 12 ) {
                    epsilon = atof(s);
                }

                else if( count == 13 ) {
                    maxeval = atoi(s);
                }

                else if( count == 14 ) {
                    amountOfRuns = atoi(s);
                    if( amountOfRuns > 1 ) multiple = 1;
                    else    multiple = 0;
                }

                else {
                    printf( "Error: Abnormal Input Sequences!!\n");
                    exit(1);
                }
            }
        }
    }
}

int find_function_type( char *s )
{
    int i, Len;

    Len = strlen(s);
    for ( i=0; i<Len; i++ ) {
        if (s[i]=='\n') Len = i;
        else s[i] = toupper(s[i]);
    }
    
    if( strncmp( s, "REAL_DECEPTIVE", Len ) == 0 )
        return RDP;
    else if( strncmp( s, "REAL_NONLINEAR", Len ) == 0 )
        return RNSP;
    else if( strncmp( s, "MICHALEWICZ", Len ) == 0 )
        return MICHALE;
    else if( strncmp( s, "ROSENBROCK", Len ) == 0 )
        return ROSEN;
    else {
        printf("There is no such a function!!\n");
        exit(1);
    }
}

void print_parameters() {
    printf("===============================\n");    
    if( saveModel )
        printf("Save learned model: YES\n" );
    else    printf("Save learned model: NO\n" );
    
    if( Optimize_Type == MIN )
        printf("Optimization type: Minize\n");
    else    printf("Optimization type: Maximize\n");

    printf("Lower range: %f\n", lowerRange );
    printf("Upper range: %f\n", upperRange );
    printf("Problem dimension: %d\n", dimensions );
    printf("Tau for trucation: %f\n", tau );
    printf("Population size: %d\n", popsize );
    printf("Num. parents: %d\n", kappa );
    printf("Num. mixtures: %d\n", numMixComponents );
    printf("Leader threshold: %f\n", leaderThreshold );
    printf("Termination 1: %f\n", epsilon );
    printf("Termination 2: %d\n", maxeval );
    printf("Num. runs: %d\n", amountOfRuns );
    printf("===============================\n\n");
}
