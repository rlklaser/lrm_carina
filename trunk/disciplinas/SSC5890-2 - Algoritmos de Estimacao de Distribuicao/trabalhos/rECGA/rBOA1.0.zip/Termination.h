/*#############################################################
  ##                                                         ##
  ##                      Termination.h                      ##
  ##           -------------------------------------         ##
  ##             Copyright (c) 2004 Chang Wook Ahn           ##
  ##         (Original Copyright (c) 2001 Peter Bosman)      ##
  ##      Gwangju Institute of Science & Technology (GIST)   ##
  ##                                                         ##
  ##               Main Work: Fitness Difference             ##
  ##                                                         ##
  ##  Difference of average fitness beween generations is    ##       
  ##    computed. It is used for terminating the run.        ##   
  ##                                                         ##
  #############################################################*/


int allEqualFitnessValues( double );
int allEqualStringGenomes( void );
int allEqualFitnessValuesSelected( double );
int allEqualFitnessValuesTauN( double );


/*
 * Returns 1 when all fitness values are equal within a certain epsilon, 0 otherwise.
 */
int allEqualFitnessValues( double epsilon )
{
  int i;

  for( i = 0; i < popsize-1; i++ )
    if( fitness[i] < (fitness[i+1] - epsilon) || fitness[i] > (fitness[i+1] + epsilon) )
      return( 0 );

  return( 1 );
}

/*
 * Returns 1 if all strings are equal on a genotypic level, 0 otherwise.
 */
int allEqualStringGenomes( void )
{
  int i;

  for( i = 0; i < popsize-1; i++ )
    if( !equalString( i, i+1 ) )
      return( 0 );

  return( 1 );
}

/*
 * Returns 1 if the best fitness in the population exceeds a specified
 * value, 0 otherwise.
 */
int bestFitnessBetterThan( double value )
{
  int i, result;

  result = 0;
  for( i = 0; i < popsize-1; i++ )
    if( BETTERFITNESS( fitness[i], value ) )
    {
      result = 1;
      break;
    }

  return( result );
}

/*
 * Returns 1 when all selected fitness values are equal within a
 * certain epsilon, 0 otherwise.
 */
int allEqualFitnessValuesSelected( double epsilon )
{
  int i;

  if( generation == 0 )
    return( 0 );

  for( i = 0; i < selsize-1; i++ )
    if( fitselected[i] < (fitselected[i+1] - epsilon) || fitselected[i] > (fitselected[i+1] + epsilon) )
      return( 0 );

  return( 1 );
}

/*
 * Returns 1 when all fitness values of the first selsize == tau*n individuals
 * are equal within a certain epsilon, 0 otherwise.
 */
int allEqualFitnessValuesTauN( double epsilon )
{
  int i;

  if( generation == 0 )
    return( 0 );

  for( i = 0; i < selsize-1; i++ )
    if( fitness[i] < (fitness[i+1] - epsilon) || fitness[i] > (fitness[i+1] + epsilon) )
      return( 0 );

  return( 1 );
}
