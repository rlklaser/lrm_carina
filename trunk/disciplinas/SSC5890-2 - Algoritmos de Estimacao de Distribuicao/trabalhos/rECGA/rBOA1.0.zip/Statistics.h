/*#############################################################
  ##                                                         ##
  ##                      Statistics.h                       ##
  ##           -------------------------------------         ##
  ##             Copyright (c) 2004 Chang Wook Ahn           ##
  ##         (Original Copyright (c) 2001 Peter Bosman)      ##
   ##     (Some addition and modification have been made.)   ##
  ##      Gwangju Institute of Science & Technology (GIST)   ##
  ##                                                         ##
  ##                  Main Work: Statistic                   ##
  ##                                                         ##
  ##  Compute and save the statistics of rBOA 1.0.           ##
  ##  Actual running time, number of fitness evaluations,    ##
  ##     and solution quality are performance measures.      ##
  ##                                                         ##
  #############################################################*/


/*------------------------------ Global Variables --------------------------------------*/
double *run_averages, *run_stdevs, *run_bests, *run_worsts, *run_evaluations, *run_secs;
/*--------------------------------------------------------------------------------------*/


void initMultipleRunStatistics( )
{
	if( multiple )
	{
		run_averages    = (double *) Malloc( amountOfRuns * sizeof( double ) );
		run_stdevs      = (double *) Malloc( amountOfRuns * sizeof( double ) );
		run_bests       = (double *) Malloc( amountOfRuns * sizeof( double ) );
		run_worsts      = (double *) Malloc( amountOfRuns * sizeof( double ) );
		run_evaluations = (double *) Malloc( amountOfRuns * sizeof( double ) );
		run_secs        = (double *) Malloc( amountOfRuns * sizeof( double ) );
	}
}

void save_statistics( double, int );
void standardStatistics( double *average, double *stdev, double *best, double *worst, int *bestpos, int *worstpos )
{
  int    i;
  double sum, sum2, val;

  if( popsize <= 0 )
  {
    *average  = 0.0;
    *stdev    = 0.0;
    *best     = 0.0;
    *worst    = 0.0;
    *bestpos  = 0;
    *worstpos = 0;
  }

  sum       = 0.0;
  sum2      = 0.0;
  *best     = fitness[0];
  *bestpos  = 0;
  *worst    = fitness[0];
  *worstpos = 0;
  for( i = 0; i < popsize; i++ )
  {
    sum  += fitness[i];
    sum2 += fitness[i] * fitness[i];
    if( BETTERFITNESS( fitness[i], *best ) )
    {
      *best    = fitness[i];
      *bestpos = i;
    }
    else if( BETTERFITNESS( *worst, fitness[i] ) )
    {
      *worst    = fitness[i];
      *worstpos = i;
    }
  }

  *average = sum / ((double) popsize);
  val      = (sum2 / ((double) popsize)) - (*average)*(*average);
  *stdev   = val <= 0 ? 0 : sqrt( val );

  /*---------------------------------------------------------------------------------------*/
  /*==  If the type of function (problem) is RDP, compute proportional correct BBs.      ==*/
  /*==  The reason is that the proportional correct BBs is actual performance measure.   ==*/
  /*==  The function "proportion_correctBB( int )" has been defined in "RealFunctions.h" ==*/
  if( Func_Type == RDP )
   *best = proportion_correctBBs( bestpos );
  /*---------------------------------------------------------------------------------------*/


  save_statistics( *best, *bestpos ); //Save statistics.

}

void save_statistics(double best_fitness, int bestpos)
{
	int i;
	FILE *fp;
	
	if( (fp=fopen("statistic", "a" )) == NULL )
		printf( "File (statistic) should not be opened!\n" );

	fprintf( fp, "%12.6lf     %8d     %12.6lf", best_fitness, evaluations, ((double) seconds)/1000.0 );

	fprintf(fp,"      ||  ");
	for( i=0; i<stringlength; i++ )
		fprintf( fp, "%12.6lf  ", GETREAL(i, bestpos) );
	fprintf(fp, "\n");
	
	fclose(fp);
}


void runningStatistics( void )
{
  int    bestpos, worstpos;
  double average, stdev, best, worst;

  standardStatistics( &average, &stdev, &best, &worst, &bestpos, &worstpos );
}

void singleRunStatistics( void )
{
	int    bestpos, worstpos;
	double average, stdev, best, worst;

	standardStatistics( &average, &stdev, &best, &worst, &bestpos, &worstpos );
  
	printf("The statistics are obtained from the population.\n");
	printf("------------------------------------------------\n");
	printf("Best Fitness     : %lg\n", best);
	printf("Worst Fitness    : %lg\n", worst);
	printf("Avg. Fitness     : %lg\n", average);
	printf("Std. Fitness     : %lg\n", stdev);	
	printf("Evaluations      : %d\n", evaluations);
	printf("Seconds          : %lg\n", ((double) seconds)/1000.0);
	printf("Evaluation Secs. : %lg\n\n", ((double) evaluationSeconds)/1000.0);
	printf("Best Individual  : ");
	print_Individual( bestpos );
	printf("Worst Individual : ");
	print_Individual( worstpos );
	printf("\n\n");
}


void multipleRunStatistics()
{
  int    i;
  double avg2, val, best, worst, evalavg2, secsavg2, evalbest, evalworst,
         averages, ev_averages, stdevs, bests, worsts, ev_stdevs, ev_bests, ev_worsts,
         secs_averages, secs_stdevs, secs_bests, secs_worsts, secsbest, secsworst;

  /* Fitness */
  averages      = 0.0;
  avg2          = 0.0;
  best          = run_bests[0];
  worst         = run_bests[0];

  /* Evaluations */
  ev_averages   = 0.0;
  evalavg2      = 0.0;
  evalbest      = run_evaluations[0];
  evalworst     = run_evaluations[0];

  /* Time */
  secs_averages = 0.0;
  secsavg2      = 0.0;
  secsbest      = run_secs[0];
  secsworst     = run_secs[0];

  for( i = 0; i < amountOfRuns; i++ )
  {
    /* Fitness */
    averages += run_bests[i];
    avg2     += run_bests[i]*run_bests[i];
    if( BETTERFITNESS( run_bests[i], best ) )
      best  = run_bests[i];
    else if( BETTERFITNESS( worst, run_bests[i] ) )
      worst = run_bests[i];

    /* Evaluations */
    ev_averages += run_evaluations[i];
    evalavg2    += run_evaluations[i]*run_evaluations[i];
    if( run_evaluations[i] < evalbest )
      evalbest  = run_evaluations[i];
    else if( evalworst < run_evaluations[i] )
      evalworst = run_evaluations[i];

    /* Time */
    secs_averages += run_secs[i];
    secsavg2      += run_secs[i]*run_secs[i];
    if( run_secs[i] < secsbest )
      secsbest  = run_secs[i];
    else if( secsworst < run_secs[i] )
      secsworst = run_secs[i];
  }

  /* Fitness */
  averages /= (double) amountOfRuns;
  val       = (avg2 / ((double) amountOfRuns)) - averages*averages;
  stdevs    = val <= 0 ? 0 : sqrt( val );
  bests     = best;
  worsts    = worst;

  /* Evaluations */
  ev_averages /= (double) amountOfRuns;
  val          = (evalavg2 / ((double) amountOfRuns)) - ev_averages*ev_averages;
  ev_stdevs    = val <= 0 ? 0 : sqrt( val );
  ev_bests     = evalbest;
  ev_worsts    = evalworst;

  /* Time */
  secs_averages /= (double) amountOfRuns;
  val            = (secsavg2 / ((double) amountOfRuns)) - secs_averages*secs_averages;
  secs_stdevs    = val <= 0 ? 0 : sqrt( val );
  secs_bests     = secsbest;
  secs_worsts    = secsworst;

  printf("The statisics are obtained from iterations.\n");
  printf("-------------------------------------------\n");
  printf("Best Fitness          : %lg\n", bests );
  printf("Worst Fitness         : %lg\n", bests, worsts);
  printf("Avg. Fitness          : %lg\n", averages);
  printf("Std. Fitness          : %lg\n", stdevs);
  printf("Smallest Evaluations  : %lf\n", ev_bests);
  printf("Largest Evaluations   : %lf\n", ev_worsts);
  printf("Avg. Evaluations      : %lf\n", ev_averages);
  printf("Std. Evaluations      : %lf\n", ev_stdevs);
  printf("Fastest Exe. Time(s)  : %lg\n", secs_bests);
  printf("Slowest Exe. Time(s)  : %lg\n", secs_worsts);
  printf("Avg. Exe. Time(s)     : %lg\n", secs_averages);
  printf("Std. Exe. Time(s)     : %lg\n", secs_stdevs);
  printf("-------------------------------------------\n\n");

}

void setMultipleRunStatistics( int run )
{
	int bestpos, worstpos;

	standardStatistics( &(run_averages[run]), &(run_stdevs[run]), &(run_bests[run]), &(run_worsts[run]), &bestpos, &worstpos );
	run_evaluations[run] = evaluations;
	run_secs[run]        = ((double) seconds)/1000.0;
}
