/******************************************************************
**                                                               **
**                   real-coded BOA (rBOA) ver 1.0               **
**                Copyright (c) 2004 Chang Wook Ahn              **
**                                                               **
**        Gwangju Institute of Science & Technology (GIST)       **
**           Deparment of Information & Communications           **
**      1 Oryong-dong, Buk-gu, Gwangju 500-712, Korea(south)     **
**   =========================================================   **
**                                                               **
**            This is the main program of rBOA 1.0               **
**                                                               **
**   This program code can be distributed for academic purposes. **
**   The program has been successfully compiled with             **
**     SunOS 5.9 (gcc) and MS Visual studio 6.0.                  **
**   Please notify me of erronous codes if any.                  **
**   The program has been built on the basis of the code of      **
**     normal mixture IDEA developed by Peter Bosman.            **
**  -----------------------------------------------------------  **
**              Primary E-mail: cwan@evolution.re.kr             **
**              Homepage: http://www.evolution.re.kr             **
**                                                               **
**                Last Update: 2004. November. 01                **
**                                                               **
*******************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <float.h>
#include <ctype.h>


/***********************************************************************
 **                          Global variables.                        **
***********************************************************************/

short  *needfit;
int     fitsize, evaluations;
long    generation, seconds, evaluationSeconds;
double *fitness, *fitselected;

/* Do not change the order. */
#include "Parameters.h"
#include "Miscellaneous.h"
#include "Matrix.h"
#include "RandomNumber.h"
#include "RealGenotype.h"
#include "RealSelection.h"
#include "RealFunctions.h"
#include "Termination.h"
#include "Statistics.h"
#include "rBOABody.h"



void IO_Setting( void ) {
    /************************* For Saving Learned Model ******************************/
    FILE *fp;    
    if( (fp=fopen("learned_model", "w" )) == NULL )
        printf( "File should not be opened!\n" );
    
    fprintf(fp,"===========================================\n");
    fprintf(fp,"####  Learned Model (i.e., Linkage)    ####\n");
    fprintf(fp,"===========================================\n");
    fclose( fp );
    /***********************************************************************************/

    /**************************** For Saving Statistics ****************************************/
    if( (fp=fopen("statistic", "w" )) == NULL )
        printf( "File (statistic) should not be opened!\n" );
    
    fprintf(fp,"=============================================================================\n");
    fprintf(fp," Fitness values    Evaluations   Execution Time ||      Best Individuals\n");
    fprintf(fp,"=============================================================================\n");  
    
    fclose( fp );
    /*******************************************************************************************/
}

/*
 * Initialize the system parameters 
 */
void init( void )
{
    /* Make files for saving results */
    IO_Setting();

    /* Read and print system parameters of rBOA */
    read_parameters();
    print_parameters();


    /* Initialize the random number generator */
    initRandom();

    fitsize = 0;

    /* Initialize the parameters for statistics */
    initMultipleRunStatistics();
}


/*
 * Running the algorithm (either multiple times or a single time)
 */
void SingleRun_rBOA( void );
void run_rBOA( void )
{
    int run;

    if( multiple )
    {
        for( run = 0; run < amountOfRuns; run++ )
        {
            printf("%d ", run); fflush(stdout);
    
            SingleRun_rBOA();

            setMultipleRunStatistics( run );
        }
    
        printf("\n");

        multipleRunStatistics();
    }
    else
        SingleRun_rBOA();
}

/*
 * Single Run of rBOA
 */
void evaluate( void );
void SingleRun_rBOA()
{
    int i, sz;

    timeMe( 1 );

    generation        = 0;
    evaluations       = 0;
    evaluationSeconds = 0;

    new_Population( popsize, dimensions, lowerRange, upperRange );
    evaluate();
    sz = (int) (tau*((double) popsize));
    
    for( i = 0; i < sz; i++ )
        needfit[i] = 0;
    for( i = sz; i < popsize; i++ )
        needfit[i] = 1;
  
    while( !allEqualFitnessValues( epsilon ) && evaluations < maxeval )
    {
        timeMe( 2 );

        realtruncationselection( sz );

        rBOA( useClusters, leaderThreshold, maximumAmountOfClusters );

        evaluationSeconds += timeMe( 2 );

        generation++;

        evaluate();
    
        for( i = 0; i < sz; i++ )
            fitness[i] = fitselected[i];
    }
    seconds           = timeMe( 1 );
    evaluationSeconds = seconds - evaluationSeconds;

    if( !multiple )
        singleRunStatistics();
}

/*
 * Evaluation of all individuals that have needfit[] set
 * to a value != 0. If the population size has changed,
 * a setup phase allocates the right amount of memory.
 */
void setupEval( void );
void performEval( void );
void evaluate( )
{
    setupEval();
    performEval();
}

/*
 * Allocates memory for evaluation of fitness values.
 */
void setupEval()
{
    short  *needdummy;
    int     i;
    double *fitdummy;

    if( fitsize < popsize )
    {
        needdummy = (short *) Malloc( popsize * sizeof( short ) );
        fitdummy  = (double *) Malloc( popsize * sizeof( double ) );
        for( i = 0; i < fitsize; i++ )
        fitdummy[i]  = fitness[i];

        if( needfit )
            free( needfit );
        if( fitness )
            free( fitness );

        needfit = needdummy;
        fitness = fitdummy;
        fitsize = popsize;
    }
    
    if( generation == 0 )
        for( i = 0; i < popsize; i++ )
            needfit[i] = 1;
}

/*
 * Computes fitness values for all individuals that require it.
 */
void performEval( void )
{
    int i;

    for( i = 0; i < popsize; i++ )
    {
        if( needfit[i] )
        {
            switch(Func_Type)
            {
                case RDP:
                    fitness[i] = cDeceptiveProblem( i );
                    break;
                case RNSP:
                    fitness[i] = cCONCRosenbrock( i );
                    break;
                case MICHALE:
                    fitness[i] = michalewiczFunction( i );
                    break;
                case ROSEN:
                    fitness[i] = rosenbrockFunction( i );
                    break;
                default:
                    printf("There is no such problem. Please add new problems.\n");
                    exit(1);
                    break;
            }

            evaluations++;
        }
    }
}


int main( int argc, char *argv[] )
{
    init();

    run_rBOA();

    return true;
}
