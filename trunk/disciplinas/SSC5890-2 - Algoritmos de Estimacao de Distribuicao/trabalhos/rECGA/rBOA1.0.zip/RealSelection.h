/*#############################################################
  ##                                                         ##
  ##                     RealSelection.h                     ##
  ##           -------------------------------------         ##
  ##             Copyright (c) 2004 Chang Wook Ahn           ##
  ##         (Original Copyright (c) 2001 Peter Bosman)      ##
  ##             (Some modification has been made.)          ##
  ##      Gwangju Institute of Science & Technology (GIST)   ##
  ##                                                         ##
  ##                   Main Work: Selection                  ##
  ##                                                         ##
  ##  Trucation as well as tournament selection  are coded.  ##
  ##                                                         ##
  #############################################################*/


/************************************************************************
 *
 * Function prototypes.
 *
 ***********************************************************************/

void  realtruncationselection( int );
int   realgetBest( void );
int   realgetWorst( void );

/**
 * Truncation selection.
 */
int *realsortPop( void );
void realmergesortPop( int *, int *, int, int );
void realmergePop( int *, int *, int, int, int );
void realtruncationselection( int amount )
{
  int i, j, *sorted;

  if( amount >= popsize )
  {
    if( amount > popsize )
    {
      printf("Warning: cannot truncate because selectSize (%d) > popSize (%d).\n", amount, popsize);
      printf("Selected all genomes.\n");
    }

    amount = popsize;
  }

    make_Selected( amount );

    sorted = realsortPop();
    for( i = 0; i < amount; i++ )
    {
      for( j = 0; j < stringlength; j++ )
        SETREALSELECTED( GETREAL( j, sorted[i] ), j, i );
      fitselected[i] = fitness[sorted[i]];
    }

    free( sorted );
}

/**
 * Sorts the population with respect to the fitness function (which fitness value
 * is better) using merge sort.
 */
int *realsortPop( void )
{
  int i, *sorted, *tosort;

  sorted = (int *) Malloc( popsize * sizeof( int ) );
  tosort = (int *) Malloc( popsize * sizeof( int ) );
  for( i = 0; i < popsize; i++ )
    tosort[i] = i;

  realmergesortPop( sorted, tosort, 0, popsize-1 );

  free( tosort );

  return( sorted );
}

/**
 * Implementation of merge sort for population sorting.
 */
void realmergesortPop( int *sorted, int *tosort, int p, int q )
{
  int r;

  if( p < q )
  {
    r = (p + q) / 2;
    realmergesortPop( sorted, tosort, p, r );
    realmergesortPop( sorted, tosort, r+1, q );
    realmergePop( sorted, tosort, p, r+1, q );
  }
}

/**
 * Subroutine of merge sort, merging the results for population sorting.
 */
void realmergePop( int *sorted, int *tosort, int p, int r, int q )
{
  int i, j, k, first;

  i = p;
  j = r;
  for( k = p; k <= q; k++ )
  {
    first = 0;
    if( j <= q )
    {
      if( i < r )
      {
        if( BETTERFITNESS( fitness[tosort[i]], fitness[tosort[j]] ) )
          first = 1;
      }
    }
    else
      first = 1;

    if( first )
    {
      sorted[k] = tosort[i];
      i++;
    }
    else
    {
      sorted[k] = tosort[j];
      j++;
    }
  }

  for( k = p; k <= q; k++ )
    tosort[k] = sorted[k];
}

/*
 * Finds the best binary string genome in the population and
 * returns the index for it.
 */
int realgetBest( void )
{
  int i, best;

  best = 0;
  for( i = 1; i < popsize; i++ )
    if( BETTERFITNESS( fitness[i], fitness[best] ) )
      best = i;

  return( best );
}

/*
 * Finds the worst binary string genome in the population and
 * returns the index for it.
 */
int realgetWorst( void )
{
  int i, worst;

  worst = 0;
  for( i = 1; i < popsize; i++ )
    if( BETTERFITNESS( fitness[worst], fitness[i] ) )
      worst = i;

  return( worst );
}

/* Tournament Selection */
void  realtournamentselection( int );

void realtournamentselection( int amount ) {
    int sel_id, sel_id1, sel_id2;

    if( amount >= popsize ) {
        printf("Error: Selection size exceeds the population size!!\n");
        exit(1);
    }
    else {
        make_Selected( amount );
        for( int i = 0; i < amount; i++ ) {
            sel_id1 = RANDOMNUMBER( popsize );
            sel_id2 = RANDOMNUMBER( popsize );
            
            if( BETTERFITNESS( fitness[sel_id1], fitness[sel_id2] ) ) sel_id = sel_id1;
            else sel_id = sel_id2;
            
            for( int j=0; j < stringlength; j++ )
                SETREALSELECTED( GETREAL( j, sel_id ), j, i );
            fitselected[i] = fitness[sel_id];
        }
    }

}
