/*
 * The XCS Library 
 * A C++ framework to apply and develop learning classifier systems
 * Copyright (C) 2002-2009 Pier Luca Lanzi and Daniele Loiacono
 * 
 * Pier Luca Lanzi and Daniele Loiacono
 * Dipartimento di Elettronica e Informazione
 * Politecnico di Milano
 * Piazza Leonardo da Vinci 32
 * I-20133 MILANO - ITALY
 * pierluca.lanzi@polimi.it - loiacono@elet.polimi.it
 *
 * This file is part of the XCSLIB library.
 *
 * xcslib is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * xcslib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * A copy of the license is available at http://www.gnu.org/licenses/gpl.html
 * 
 * If you use this code, please cite the following technical report:
 *
 * P.L. Lanzi and D. Loiacono (2009), "XCSLib: The XCS Classifier System Library", 
 * Technical Report No. 2009005, Illinois Genetic Algorithms Laboratory
 * University of Illinois at Urbana-Champaign, 117 Transportation Building
 * 104 S. Mathews Avenue Urbana, IL 61801
 * 
 * Available at http://www.illigal.uiuc.edu/pub/papers/IlliGALs/2009005.pdf
 *
 * For updates please visit: http://xcslib.sf.net 
 *                           http://www.pierlucalanzi.net
 */




//-------------------------------------------------------------------------
// Filename      : xcsf_classifier_system.hh
//
// Purpose       : definition of the multiplexer class
//
// Special Notes :
//
//
// Creator       : Pier Luca Lanzi
//
// Creation Date : 2002/05/14
//
// Current Owner : Pier Luca Lanzi
//-------------------------------------------------------------------------
// Updates
//	2005 05 12 added flag_bounded_payoff to bound the payoff range 
//                 it is used to check whether we can control divergence
//                 in multistep problems with a discount factor of 1
//	2004 09 22 added methods value(s,a), values(s), and load_population(fn) 
//	2003 08 16 added tournament selection size parameter
// 	2003 08 07 general.hh becomes xcs_definitions
//-------------------------------------------------------------------------

/*!
 * \file xcsf_classifier_system.hh
 *
 * \brief implements the XCS classifier system
 *
 */

#include <list>
#include "xcs_definitions.hpp"
#include "xcs_random.hpp"
#include "xcs_config_mgr2.hpp"

using namespace std;

#ifndef __XCSF_CLASSIFIER_SYSTEM__
#define __XCSF_CLASSIFIER_SYSTEM__

#define __XCS_CFG__ " \
      Population Size = %lu \n\
        Learning Rate = %lf \n\
           Error Rate = %lf \n\
      Discount Factor = %lf \n\
    covering strategy = %s %lf \n\
  discovery component = %s \n\
             theta GA = %lf \n\
            Crossover = %lf \n\
             Mutation = %lf \n\
         epsilon zero = %lf \n\
                   vi = %lf \n\
                alpha = %lf \n\
      prediction init = %lf \n\
           error init = %lf \n\
         fitness init = %lf \n\
        set size init = %lf \n\
      population init = %s \n\
 exploration strategy = %s \n\
    deletion strategy = %s \n\
         theta delete = %lf \n\
         theta GA sub = %lf \n\
         theta AS sub = %lf \n\
       GA subsumption = %s \n\
       AS subsumption = %s \n\
   Update Error First = %s \n\
              Use MAM = %s \n\
GA Tournament Selection = %s \n\
        Tournament size = %lf \n\
        Normalize Input = %s\n\
        Gradient = %s\n\
        SARSA = %s\n\
"

#define __XCS_VARS_IN__ \
	&max_population_size, \
	&learning_rate, \
        &error_rate, \
	&discount_factor,\
	str_covering, &covering_threshold, \
	str_discovery_component, &theta_ga, &prob_crossover, &prob_mutation, \
	&epsilon_zero, &vi, &alpha,\
	\
	&init_prediction, &init_error, &init_fitness, &init_set_size, \
	\
	str_pop_init, \
	str_exploration, \
	DeleteWithAccuracyString, \
	&theta_del, \
	&theta_sub, \
	&theta_as_sub, \
	str_ga_sub, \
	str_as_sub, \
	str_error_first, \
	str_use_mam, \
	str_ga_ts, &tournament_size, \
        str_norm_input,\
        str_gradient,\
        str_sarsa

#define __XCS_VARS_OUT__ \
	max_population_size, \
	learning_rate, \
        error rate, \
	discount_factor,\
	str_covering, covering_threshold, \
	str_discovery_component, theta_ga, prob_crossover, prob_mutation, \
	epsilon_zero, vi, alpha,\
	\
	init_prediction, init_error, init_fitness, init_set_size, \
	\
	str_pop_init, \
	str_exploration, \
	DeleteWithAccuracyString, \
	theta_del, \
	theta_sub, \
	theta_as_sub, \
	str_ga_sub, \
	str_as_sub, \
	str_error_first, \
	str_use_mam, \
	str_ga_ts, tournament_size, \
        str_norm_input,\
        str_sarsa

#define __XCS_OPT_CFG__ " \
      GA Subsumption in [A] = %s\n \
"
#define __XCS_OPT_VARS_IN__ \
	str_gaa_subsumption


//! covering strategy
typedef enum {
 	COVERING_STANDARD,	//! perform covering based on the average prediction of [M] and [P]
	COVERING_ACTION_BASED	//! perform covering based on the number of actions in [M]
} t_covering_strategy;

//! action selection strategy
typedef enum {
 	ACTSEL_DETERMINISTIC,	// sceglie azione con predizione migliore
	ACTSEL_UNIFORM,			// sceglie azione a caso
	ACTSEL_SEMIUNIFORM, 	// Uniform con prob. biased deterministico
	ACTSEL_PROPORTIONAL, 	// Prob. proporzionale alla predizione
} t_action_selection;

//! population init strategy
typedef enum {
	INIT_RANDOM, 		// random population
	INIT_EMPTY, 		// empty population
	INIT_LOAD, 		// empty population
} t_classifier_set_init;

/*!
 * \brief implements the elements of the prediction array
 */
class t_system_prediction {
 public:
        double		payoff;		//! action payoff
        t_action	action;		//! action
        double		sum;		//! fitness sum to normalize action payoff
	unsigned long 	n;		//! number of classifiers that advocate the action

	t_system_prediction()
	{
		payoff = 0;
		sum = 0;
		n = 0;
	};

	int operator==(const t_system_prediction& p2) const
	{	// due predizioni sono 'uguali' se si riferiscono alla stessa azione
		return (action == p2.action);
	}

	int operator==(const t_action& act) const
	{	// due predizioni sono 'uguali' se si riferiscono alla stessa azione
		return (action == act);
	}
};

/*!
 * \class xcs_statistics
 * \brief collects various XCS statistics
 */
class xcs_statistics
{
	public:
		double	average_prediction;		//! average prediction in [P]
		double	average_fitness;		//! average fitness in [P]
		double	average_error;			//! average prediction error in [P]
		double	average_actionset_size;		//! average size of [A]
		double	average_experience;		//! average experience
		double	average_numerosity;		//! average numerosity
		double	average_time_stamp;		//! average time stampe
		double	average_no_updates;		//! average number of classifier updates
		double	system_error;			//! system error in [P]

		unsigned long no_macroclassifiers;	//! number of macroclassifiers in [P]
		unsigned long no_ga;			//! number of GA activations
		unsigned long no_cover;			//! number of covering activations
		unsigned long no_subsumption;		//! number of subsumption activations

		//! class constructor; it invokes the reset method \sa reset
		xcs_statistics();

		//! reset all the collected statistics
		void reset();

		//! read the statistics from an output stream
		friend istream& operator>>(istream&, xcs_statistics&);

		//! write the statistics to an output stream
		friend ostream& operator<<(ostream&, const xcs_statistics&);
};

/*!
 * \class xcsf_classifier_system
 * \brief implements the XCS classifier system
 */
class xcsf_classifier_system
{
 public:
	//! name of the class that implements XCS
	string class_name() const {return string("xcsf_classifier_system");};

	//! tag used to access the configuration file
	string tag_name() const {return string("classifier_system");};

	//! class constructor
	xcsf_classifier_system(xcs_config_mgr2& xcs_config);

	/**
	 * methods used from the experiment manager
	 */

	//@{

	//! defines what has to be done when a new experiment begins
	void	begin_experiment();

	//! defines what has to be done when the current experiment begins
	void	end_experiment();

	//! defines what has to be done when a new problem begins.
	void	begin_problem();

	//! defines what must be done when the current problem ends
	void	end_problem();

	//! return the size of memory that is used during learning, i.e., the number of macro classifiers in [P]
	unsigned long size() const
        {

          //#D v0.2
          return population.size();

          //#A v0.2
          //return population_size;


        };

	//! writes trace information on an output stream;
	/*!
	 * it is called by the experiment manager just before the end_problem method
	 * \sa end_problem
	 * \sa \class experiment_mgr
	 */

private:
    double system_error;			//! measure the current system error
public:
	double system_err() const {return system_error;};
	
    	void trace(ostream& output);

	//!	return the statistics of the current experiment
	xcs_statistics statistics() const {return stats;};

	//!	restore XCS state from an input stream
	void	restore_state(istream& input);


        //#A BEGIN v1.1
        //!	restore XCS population from an input stream
	void	restore_population(istream& input);
        //#A END


	//!	save the experiment state to an output stream
	void	save_state(ostream& output);

	//!	save the population state to an output stream
	void	save_population_state(ostream& output);

	//!	save population
	void	save_population(ostream& ouput);

	//@}

 public:
	//================================================================================
	//
	//
	//	PUBLIC TYPES
	//
	//
	//================================================================================

	//! pointer to a classifier
	typedef t_classifier*				t_classifier_ptr;

	//! set of classifiers
	/*!
	 * \type t_classifier_set
	 * \brief represent a set of classifiers
	 */
	typedef vector<t_classifier*>			t_classifier_set;

	//! index in set of classifiers
	/*!
	 * \type t_set_iterator
	 * \brief represent an iterator over a set of classifiers
	 */
	typedef vector<t_classifier*>::iterator	t_set_iterator;
	typedef vector<t_classifier*>::const_iterator	t_set_const_iterator;

private:
	//================================================================================
	//
	//
	//	PERFORMANCE COMPONENT
	//
	//
	//================================================================================

	bool			init;				//! true, if the class was initialized
	t_environment		*environment;			//! link to the environment

	//! experiment parameters
	unsigned long		total_steps;			//! total number of steps
	unsigned long		total_learning_steps;		//! total number of exploration steps
	unsigned long		total_time;			//! total time passed (should be the same as total steps);
	unsigned long		problem_steps;			//! total number of steps within the single problem
	double			total_reward;			//! total reward gained during the problem

	//! [P] parameters
	unsigned long		max_population_size;		//! maximum number of micro classifiers
	unsigned long		population_size;		//! population size
	unsigned long		macro_size;			//! number of macroclassifiers
	t_classifier_set_init	population_init;		//! init strategy for [P]
	string			population_init_file;		//! file containing a population to be used to init [P]

	//! classifier parameters
	double			init_prediction;		//! initial prediction for newly created classifiers
	double			init_error; 			//! initial predition error for newly created classifiers
	double			init_fitness; 			//! initial fitness for newly created classifiers
	double			init_set_size;			//! initial set size for newly created classifiers
	unsigned long		init_no_updates;		//! initial number of updates for newly created classifiers

	//! covering strategy
	t_covering_strategy	covering_strategy;		//! strategy for create covering classifiers
	double			fraction_for_covering;		//! original covering parameter in Wilson's 1995 paper
	double	 		tetha_nma;			//! minimum number of actions in [M]

	//! action selection
	t_action_selection	action_selection_strategy;	//! strategy for action selection
	double			prob_random_action;		//! probability of random action
        
        ofstream          AVFSTAT;
        t_action	  prev_action;
        bool              flag_sarsa;
        
        bool              flag_gradient;
        

	///================================================================================
	///
	///
	///	REINFORCEMENT COMPONENT
	///
	///
	///================================================================================

	//! fitness computation
	double			epsilon_zero;			//! epsilon zero parameter, determines the threshold
	double			alpha; 				//! alpha parameter, determines the start of the decay
	double			vi;				//! vi parameter, determines the decay rate
	bool			use_exponential_fitness;	//! if true exponential fitness is used


	//================================================================================
	//
	//
	//	DISCOVERY COMPONENT
	//
	//
	//================================================================================

	//! GA parameters
	bool			flag_discovery_component;	//! true if the GA is on
	double			theta_ga;			//! threshold for GA activation
	double			prob_crossover;			//! probability to apply crossover
	double			prob_mutation;			//! probability to apply mutation
	bool			flag_ga_average_init;		//! if true offspring parameters are averages
	bool			flag_error_update_first;	//! if true, prediction error is updated first

	bool			use_ga;				//! true if GA is on
	bool			use_crossover;			//! true if crosseover is used
	bool			use_mutation;			//! true if mutation is used

	//! subsumption deletion parameters
	bool			flag_ga_subsumption;		//! true if GA subsumption is on
	bool			flag_as_subsumption;		//! true if AS subsumption is on
	double			theta_sub;			//! threshold for subsumption activation
	double	 		theta_as_sub;			//! threshold for subsumption activation
	bool			flag_cover_average_init;

	bool			flag_gaa_subsumption;		//! true if GA subsumption is applied also to [A]

	//! delete parameters
	bool			flag_delete_with_accuracy;	//! deletion strategy: true, if T3 is used; false if T1 is used
	double			theta_del;			//! theta_del parameter for deletion
	double			delta_del;			//! delta parameter for deletion

	//================================================================================
	//
	//
	//	OTHER PRIVATE FUNCTIONS
	//
	//
	//================================================================================

	xcs_statistics stats;					//! classifier system statistics

        //#A v0.4
        bool flag_norm_input;

 public:
	//================================================================================
	//
	//
	//	REINFORCEMENT COMPONENT
	//
	//
	//================================================================================

	double	learning_rate;					//! beta parameter
        double  error_rate;                                     //! epsilon parameter
	double	discount_factor;				//! gamma parameter, the discount factor

	//================================================================================
	//
	//
	//	METHODS FOR THE DISCOVERY COMPONENT
	//
	//
	//================================================================================

 private:
	//! private methods for GA
	//@{
	bool	need_ga(t_classifier_set &action_set, const bool flag_explore);
	void	select_offspring(t_classifier_set&, t_set_iterator&, t_set_iterator&);
	//void	genetic_algorithm(t_classifier_set &action_set, const t_state& detectors, const bool flag_condensation);
	void	genetic_algorithm(t_classifier_set &action_set, const t_state& detectors, const bool flag_condensation=false );
	//@}

 private:

	//! variables for [P], [M], [A], and [A]-1
	//@{
	t_classifier_set 				population;			//! population [P]
	t_classifier_set				match_set;			//! match set [M]
	t_classifier_set				action_set;			//! action set [A]
	t_classifier_set				previous_action_set;		//! action set at previous time step [A]-1
	//@}

	vector<double>					select;				//! vector for roulette wheel selection
	vector<double>					error;

	t_state					previous_input;			//! input at t-1
	t_state					current_input;			//! current input at time t
	vector<t_system_prediction>			prediction_array;		//! prediction array P(.)
	vector<unsigned long>				available_actions;		//! actions in the prediction array that have a not null prediction, and thus are available for selection

	double		previous_reward;						//! reward received at previous time step


	//! methods for setting the parameters from the configuration file
	//@{
	void	set_init_strategy(string);
	void	set_exploration_strategy(const char* explorationType);
	void	set_deletion_strategy(const char* deleteType);
	void	print_options(ostream& output) const;
	void	set_covering_strategy(const string strategy, double);			//! set the covering strategy, which can be "standard" or "nma"
	//@}

	//! methods for [P]
	//@{
	void	clear_population();				//! empty [P]
	void    init_classifier_set();				//! init [P] according to the selected strategy (i.e., empty or random)

	void	erase_population();				//! erase [P]
	void	insert_classifier(t_classifier& cs);		//! insert a classifier in [P]
	void	delete_classifier();				//! delete a classifier from [P]

	//! init the classifier parameters
	void	init_classifier(t_classifier& classifier, bool average=false);
	//void	init_classifier(t_classifier& classifier, bool average);
	//@}

	//! methods for covering
	//@{
	bool	need_covering_standard(t_classifier_set, const t_state&);	//! true if covering is needed according to Wilson 1995

	void	covering(const t_state& detectors);				//! covering
	bool	perform_covering(t_classifier_set&, const t_state&);		//! perform covering in [M]

	bool	perform_standard_covering(t_classifier_set&, const t_state&); //! perform covering according to Wilson 1995
	bool	need_standard_covering(t_classifier_set&, const t_state&);	//! true if standard covering is needed

	bool	perform_nma_covering(t_classifier_set&, const t_state&);	//! perform covering according to Butz and Wilson 2001

	//@}


        //#M BEGIN v
        //!	build the prediction array P(.) from [M]
	void	build_prediction_array(vector<double>& current_input);
        //#M END

        //! 	print the prediction array P(.) to an output stream
	void	print_prediction_array(ostream&);


	//! select an action
	void	select_action(const t_action_selection, t_action&);

	//!	build [A] based on the selected action a
	void	build_action_set(const t_action&);

	//! methods for distributing the reinforcement among classifiers
	//@{

        //#M BEGIN v1.0
        void	update_set(const double, t_classifier_set&, vector<double>&);
        //#M END

	void	update_fitness(t_classifier_set&);
	//@}

	//! true if classifier \emph first subsume classifier \emph second
	bool 	subsume(const t_classifier& first, const t_classifier& second);

 public:
	//@{
	/*!
	 * find the classifiers that are AS subsumed in the current set
	 * \param set input classifiers
	 * \param set classifiers that are AS subsumed
	 */
	void	do_as_subsumption(t_classifier_set &set);

	//!	find the "most general classifier in the set
	//t_set_iterator find_most_general(t_classifier_set&) const;
	t_set_iterator find_most_general(t_classifier_set&) const;

	//! 	find the classifiers in the set that are subsumed by classifier
	void	find_as_subsumed(t_set_iterator, t_classifier_set&, t_classifier_set&) const;

	//!	perform AS subsumption, deleting the subsumed classifiers and increasing the numerosity of most general classifier
	void	as_subsume(t_set_iterator, t_classifier_set &set);

	//@}
 public:

        //#M BEGIN v0.1
        //!	a step of a problem
	void	step(const bool exploration_mode,const bool condensationMode, const bool do_update=true);
        //#M END

        //!	a step of a problem
        void test(t_state input, ostream &output);

	//!  build the match set [M]; it returns the number of microclassifiers that match the sensory configuration
	unsigned long	match(const t_state& detectors);

 private:
	//! true if the problem is solved in exploration (Wilson 1995), i.e., XCS is in learning (Butz 2001)
	bool		exploration_mode;
 public:
	//! total number of learning steps
	unsigned long	learning_time() const {return total_learning_steps;};

	//! total number of steps
	unsigned long	time() const {return total_steps;};

	//! total number of steps within the current problem
	unsigned long	problem_time() const {return problem_steps;};

	//! return true if the XCS is solving the problem in exploration
	bool	in_exploration() {return exploration_mode;};

	//! set the exploration mode: if mode is true problems will be solved in exploration
	void	exploration(bool mode) {exploration_mode = mode;};

	/*!
	 * TRAIN/TEST FUNCTIONS
	 */
	void train(t_state&, t_action&, double) {};
	void test(t_state&, t_action&, double) {};

 private:
	bool	classifier_could_subsume(const t_classifier &classifier, double epsilon_zero, double theta_sub) const
		{ 
//			cout << "Existing classifier experience= " << classifier.experience;
//			cout << "  Theta sub= " << theta_sub << endl;
//			cout << "Existing classifier error= " << classifier.error;
//			cout << "  Epsilon zero= " << epsilon_zero;
			return ((classifier.experience>theta_sub) && (classifier.error<epsilon_zero)); 
		};

 private:
	//! create the prediction array based on the action used
	void	create_prediction_array();

	//! clear the prediction array based
	void	init_prediction_array();

	//@{ \defgroup procedures to trace execution

	//! print a set of classifiers
	void print_set(t_classifier_set &set, ostream& output, string label="");

	//! check the consistency of various parameters in [P]
	void	check(string,ostream&);
	//@}

	bool comp_num(const t_classifier& cl1, const t_classifier& cl2) const {return (cl1.numerosity>cl2.numerosity);};

	class comp_numerosity {
  	  public:
	  int operator()(const xcsf_classifier_system::t_classifier_ptr &first, const xcsf_classifier_system::t_classifier_ptr &second)
	  {
	    return (first->numerosity>second->numerosity);
	  };
	};

	class comp_experience {
  	  public:
	  int operator()(const xcsf_classifier_system::t_classifier_ptr &first, const xcsf_classifier_system::t_classifier_ptr &second)
	  {
	    return (first->experience>second->experience);
	  };
	};

 private:
	//! configuration
	const string	configuration[];

 private:
 	//! new random init procedure
	void init_population_random();

 	//! new random init procedure
	void init_population_load(string);

 private:
	//! new configuration parameters 2003/05/06

	bool			flag_use_mam;
	bool			flag_ga_tournament_selection;
	bool                    flag_tournament_on_fitness;

        double 			tournament_size;


private:
        string                  extension;


	//! select offspring classifier through tournament selection
	void select_offspring_ts(t_classifier_set&, t_set_iterator&);

public:
	void ga_a_subsume(t_classifier_set&, const t_classifier&, t_set_iterator&);

	double get_system_error() const {return system_error;};

private:
	//! true if the payoff is bound 
	bool flag_bounded_payoff;
	bool flag_update_test;
	bool flag_use_gradient_descent;
	bool flag_normalize_input;

};
#endif
